"""Identity & Trust layer.

Implements:
  - Cryptographic identities (Ed25519 when `cryptography` is available; an
    OS-verified HMAC backend otherwise) issued to every agent/user/service.
  - DID-style identifiers (did:proto:<key-hash>) with DID Documents, plus a
    did:web / ANP did:wba style alias mechanism backed by well-known documents.
  - Verifiable Credentials (signed claim envelopes with expiry).
  - Short-lived session tokens and RFC 8693-style token exchange (an `act`
    chain records on-behalf-of delegation).
  - A minimal enterprise IdP (OIDC-shaped) bridge stub mapping external
    subjects onto Proto identities (TAP-style agent identity bridging).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os as _os
from dataclasses import dataclass, field
from pathlib import Path

from .canonical import Clock, ProtoError, b32, cjson, new_id, sha256_hex

try:  # Real public-key signatures when available.
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )

    _HAVE_ED25519 = True
except Exception:  # pragma: no cover - fallback environment
    _HAVE_ED25519 = False


class KeyBackend:
    name = "abstract"

    def new_keypair(self):  # -> (private_handle, public_bytes)
        raise NotImplementedError

    def sign(self, private_handle, data: bytes) -> bytes:
        raise NotImplementedError

    def verify(self, public_bytes: bytes, signature: bytes, data: bytes) -> bool:
        raise NotImplementedError


class Ed25519Backend(KeyBackend):
    name = "ed25519"

    def new_keypair(self):
        priv = Ed25519PrivateKey.generate()
        pub = priv.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
        return priv, pub

    def sign(self, private_handle, data: bytes) -> bytes:
        return private_handle.sign(data)

    def verify(self, public_bytes: bytes, signature: bytes, data: bytes) -> bool:
        try:
            Ed25519PublicKey.from_public_bytes(public_bytes).verify(signature, data)
            return True
        except InvalidSignature:
            return False
        except Exception:
            return False


class HmacBackend(KeyBackend):
    """Fallback: HMAC-SHA256 with OS-held secrets.

    Not third-party verifiable public-key crypto; verification is performed by
    the control plane which holds the secrets. Documented limitation.
    """

    name = "hmac-sha256"

    def __init__(self):
        self._secrets: dict[bytes, bytes] = {}

    def new_keypair(self):
        secret = _os.urandom(32)
        pub = hashlib.sha256(b"hmac-pub" + secret).digest()
        self._secrets[pub] = secret
        return secret, pub

    def sign(self, private_handle, data: bytes) -> bytes:
        return hmac.new(private_handle, data, hashlib.sha256).digest()

    def verify(self, public_bytes: bytes, signature: bytes, data: bytes) -> bool:
        secret = self._secrets.get(public_bytes)
        if secret is None:
            return False
        return hmac.compare_digest(hmac.new(secret, data, hashlib.sha256).digest(), signature)


def default_backend() -> KeyBackend:
    return Ed25519Backend() if _HAVE_ED25519 else HmacBackend()


@dataclass
class Identity:
    did: str
    name: str
    kind: str  # agent | user | service | merchant
    public_key_hex: str
    created: float
    labels: dict = field(default_factory=dict)

    def did_document(self) -> dict:
        return {
            "@context": ["https://www.w3.org/ns/did/v1"],
            "id": self.did,
            "verificationMethod": [
                {
                    "id": f"{self.did}#key-1",
                    "type": "Ed25519VerificationKey2020",
                    "controller": self.did,
                    "publicKeyHex": self.public_key_hex,
                }
            ],
            "authentication": [f"{self.did}#key-1"],
            "service": [],
        }


class IdentityService:
    def __init__(self, backend: KeyBackend, clock: Clock, wellknown_root: Path | None = None):
        self.backend = backend
        self.clock = clock
        self._priv: dict[str, object] = {}
        self._identities: dict[str, Identity] = {}
        self._web_alias: dict[str, str] = {}  # did:web:<host> -> did:proto:...
        self._revoked_tokens: set[str] = set()
        self.wellknown_root = Path(wellknown_root) if wellknown_root else None
        self.service_identity = self.create_identity("proto-os", "service")

    # ---- identity lifecycle -------------------------------------------------
    def create_identity(self, name: str, kind: str, labels: dict | None = None) -> Identity:
        priv, pub = self.backend.new_keypair()
        did = f"did:proto:{b32(hashlib.sha256(pub).digest()[:20])}"
        ident = Identity(
            did=did,
            name=name,
            kind=kind,
            public_key_hex=pub.hex(),
            created=self.clock.now(),
            labels=labels or {},
        )
        self._priv[did] = priv
        self._identities[did] = ident
        return ident

    def get(self, did: str) -> Identity:
        d = self.resolve_alias(did)
        if d not in self._identities:
            raise ProtoError(f"unknown identity {did}")
        return self._identities[d]

    def resolve_alias(self, did: str) -> str:
        return self._web_alias.get(did, did)

    def resolve_document(self, did: str) -> dict:
        return self.get(did).did_document()

    # ---- did:web / ANP-style open publication --------------------------------
    def register_web_alias(self, did: str, host: str) -> str:
        """Bind an identity to did:web:<host> and publish its document under
        <root>/<host>/.well-known/did.json (open-internet / ANP mode, simulated
        on the local filesystem because container egress is disabled)."""
        alias = f"did:web:{host}"
        self._web_alias[alias] = did
        if self.wellknown_root is not None:
            p = self.wellknown_root / host / ".well-known"
            p.mkdir(parents=True, exist_ok=True)
            doc = self.get(did).did_document()
            doc["alsoKnownAs"] = [alias]
            (p / "did.json").write_text(cjson(doc))
        return alias

    # ---- signing -------------------------------------------------------------
    def sign_as(self, did: str, data) -> str:
        if isinstance(data, dict):
            data = cjson(data)
        if isinstance(data, str):
            data = data.encode("utf-8")
        priv = self._priv.get(self.resolve_alias(did))
        if priv is None:
            raise ProtoError(f"no private key for {did}")
        return self.backend.sign(priv, data).hex()

    def verify_for(self, did: str, signature_hex: str, data) -> bool:
        if isinstance(data, dict):
            data = cjson(data)
        if isinstance(data, str):
            data = data.encode("utf-8")
        try:
            ident = self.get(did)
            return self.backend.verify(
                bytes.fromhex(ident.public_key_hex), bytes.fromhex(signature_hex), data
            )
        except Exception:
            return False

    # ---- verifiable credentials ----------------------------------------------
    def issue_vc(self, issuer_did: str, subject_did: str, claims: dict, ttl: float = 3600.0) -> dict:
        now = self.clock.now()
        body = {
            "@context": ["https://www.w3.org/ns/credentials/v2"],
            "type": ["VerifiableCredential"],
            "id": new_id("vc"),
            "issuer": issuer_did,
            "credentialSubject": {"id": subject_did, **claims},
            "issuanceDate": now,
            "expirationDate": now + ttl,
        }
        proof = {
            "type": "ProtoSignature2026",
            "verificationMethod": f"{issuer_did}#key-1",
            "signature": self.sign_as(issuer_did, body),
        }
        return {**body, "proof": proof}

    def verify_vc(self, vc: dict) -> tuple[bool, str]:
        body = {k: v for k, v in vc.items() if k != "proof"}
        if vc.get("expirationDate", 0) < self.clock.now():
            return False, "expired"
        if not self.verify_for(vc["issuer"], vc["proof"]["signature"], body):
            return False, "bad-signature"
        return True, "ok"

    # ---- session tokens & RFC 8693-style exchange ------------------------------
    def issue_token(self, sub: str, aud: str, scope: list[str], ttl: float = 900.0,
                    act: list[str] | None = None) -> dict:
        now = self.clock.now()
        body = {
            "iss": self.service_identity.did,
            "sub": sub,
            "aud": aud,
            "scope": sorted(scope),
            "iat": now,
            "exp": now + ttl,
            "jti": new_id("tok"),
        }
        if act:
            body["act"] = act
        return {**body, "sig": self.sign_as(self.service_identity.did, body)}

    def verify_token(self, token: dict, expected_aud: str) -> tuple[bool, str]:
        body = {k: v for k, v in token.items() if k != "sig"}
        if token.get("jti") in self._revoked_tokens:
            return False, "revoked"
        if token.get("exp", 0) < self.clock.now():
            return False, "expired"
        if token.get("aud") != expected_aud:
            return False, "wrong-audience"
        if not self.verify_for(token["iss"], token["sig"], body):
            return False, "bad-signature"
        return True, "ok"

    def exchange_token(self, token: dict, new_aud: str, scope: list[str] | None = None) -> dict:
        ok, why = self.verify_token(token, token.get("aud"))
        if not ok:
            raise ProtoError(f"token exchange refused: {why}")
        act = list(token.get("act", [])) + [token["sub"]]
        return self.issue_token(
            sub=token["sub"], aud=new_aud, scope=scope or token["scope"], act=act
        )

    def revoke_token(self, token: dict) -> None:
        self._revoked_tokens.add(token.get("jti", ""))


class EnterpriseIdPStub:
    """OIDC-shaped enterprise IdP used to demonstrate the OAuth/OIDC + TAP
    bridge: external subjects authenticate here, then `bridge_to_proto`
    exchanges the external assertion for a Proto session token."""

    def __init__(self, issuer: str, ids: IdentityService):
        self.issuer = issuer
        self.ids = ids
        self._idp_identity = ids.create_identity(issuer, "service")
        self._users: dict[str, str] = {}

    def add_user(self, external_sub: str, password: str) -> None:
        self._users[external_sub] = sha256_hex(password)

    def authenticate(self, external_sub: str, password: str) -> dict:
        if self._users.get(external_sub) != sha256_hex(password):
            raise ProtoError("idp: bad credentials")
        now = self.ids.clock.now()
        body = {"iss": self.issuer, "sub": external_sub, "iat": now, "exp": now + 600,
                "typ": "id_token"}
        return {**body, "sig": self.ids.sign_as(self._idp_identity.did, body)}

    def bridge_to_proto(self, id_token: dict, proto_did: str, scope: list[str]) -> dict:
        body = {k: v for k, v in id_token.items() if k != "sig"}
        if id_token.get("exp", 0) < self.ids.clock.now():
            raise ProtoError("idp token expired")
        if not self.ids.verify_for(self._idp_identity.did, id_token["sig"], body):
            raise ProtoError("idp token invalid")
        return self.ids.issue_token(sub=proto_did, aud="proto-os", scope=scope,
                                    act=[f"{self.issuer}:{id_token['sub']}"])
