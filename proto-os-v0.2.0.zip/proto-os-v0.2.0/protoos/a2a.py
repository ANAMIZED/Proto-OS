"""A2A adapter + AG-UI event bus.

A2A (reference-shaped): Tasks with the A2A lifecycle states — submitted,
working, input-required, completed, failed, canceled — driven by registered
per-agent handlers; message/send, tasks/get, tasks/cancel and input resume.
Long-running work is modelled by tasks parking in `input-required` and
resuming later, alongside SessionManager contexts.

AG-UI (reference-shaped): an ordered event stream per run — RUN_STARTED,
TEXT_MESSAGE, TOOL_CALL_START/END, STATE_DELTA, HUMAN_INPUT_REQUEST/RESULT,
RUN_FINISHED, ERROR — with multi-client subscription and shared state.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .audit import AuditLog
from .canonical import Clock, ProtoError, new_id

# A2A task states
SUBMITTED, WORKING, INPUT_REQUIRED = "submitted", "working", "input-required"
COMPLETED, FAILED, CANCELED = "completed", "failed", "canceled"
TERMINAL = {COMPLETED, FAILED, CANCELED}


class InputRequired(Exception):
    """Raised by a handler to park the task awaiting more input."""

    def __init__(self, prompt: str):
        super().__init__(prompt)
        self.prompt = prompt


@dataclass
class Task:
    id: str
    context_id: str
    agent: str
    state: str = SUBMITTED
    history: list[dict] = field(default_factory=list)
    artifacts: list[dict] = field(default_factory=list)
    meta: dict = field(default_factory=dict)
    created: float = 0.0
    updated: float = 0.0

    def to_json(self) -> dict:
        return {"id": self.id, "contextId": self.context_id, "agent": self.agent,
                "status": {"state": self.state}, "history": self.history,
                "artifacts": self.artifacts, "metadata": self.meta}


class A2AAdapter:
    def __init__(self, clock: Clock, audit: AuditLog):
        self.clock, self.audit = clock, audit
        self._handlers: dict[str, object] = {}
        self.tasks: dict[str, Task] = {}

    def register_handler(self, agent_did: str, handler) -> None:
        """handler(task, message_text, os_ctx) -> result parts (str|dict) or
        raises InputRequired."""
        self._handlers[agent_did] = handler

    def message_send(self, to_did: str, message: str, context_id: str | None = None,
                     meta: dict | None = None, os_ctx=None) -> Task:
        if to_did not in self._handlers:
            raise ProtoError(f"a2a: no handler registered for {to_did}")
        t = Task(id=new_id("task"), context_id=context_id or new_id("ctx"), agent=to_did,
                 meta=meta or {}, created=self.clock.now(), updated=self.clock.now())
        t.history.append({"role": "user", "parts": [{"kind": "text", "text": message}]})
        self.tasks[t.id] = t
        self.audit.append(to_did, "a2a.task_submitted",
                          {"task": t.id, "context": t.context_id, "meta": t.meta})
        return self._run(t, message, os_ctx)

    def _run(self, t: Task, message: str, os_ctx) -> Task:
        t.state = WORKING
        t.updated = self.clock.now()
        try:
            result = self._handlers[t.agent](t, message, os_ctx)
        except InputRequired as need:
            t.state = INPUT_REQUIRED
            t.history.append({"role": "agent",
                              "parts": [{"kind": "text", "text": need.prompt}]})
            self.audit.append(t.agent, "a2a.input_required",
                              {"task": t.id, "prompt": need.prompt})
            return t
        except Exception as exc:
            t.state = FAILED
            t.history.append({"role": "agent",
                              "parts": [{"kind": "text",
                                         "text": f"error: {type(exc).__name__}: {exc}"}]})
            self.audit.append(t.agent, "a2a.task_failed", {"task": t.id, "error": str(exc)})
            return t
        t.state = COMPLETED
        part = result if isinstance(result, dict) else {"kind": "text", "text": str(result)}
        t.artifacts.append({"artifactId": new_id("art"), "parts": [part]})
        t.history.append({"role": "agent", "parts": [part]})
        t.updated = self.clock.now()
        self.audit.append(t.agent, "a2a.task_completed", {"task": t.id})
        return t

    def provide_input(self, task_id: str, message: str, os_ctx=None) -> Task:
        t = self.tasks_get(task_id)
        if t.state != INPUT_REQUIRED:
            raise ProtoError(f"a2a: task {task_id} is not awaiting input")
        t.history.append({"role": "user", "parts": [{"kind": "text", "text": message}]})
        return self._run(t, message, os_ctx)

    def tasks_get(self, task_id: str) -> Task:
        if task_id not in self.tasks:
            raise ProtoError(f"a2a: unknown task {task_id}")
        return self.tasks[task_id]

    def cancel(self, task_id: str) -> Task:
        t = self.tasks_get(task_id)
        if t.state not in TERMINAL:
            t.state = CANCELED
            t.updated = self.clock.now()
            self.audit.append(t.agent, "a2a.task_canceled", {"task": t.id})
        return t

    def handle(self, req: dict, os_ctx=None) -> dict:
        """JSON-RPC surface: message/send, tasks/get, tasks/cancel."""
        method, id_, p = req.get("method"), req.get("id"), req.get("params") or {}
        try:
            if method == "message/send":
                t = self.message_send(p["to"], p["message"], p.get("contextId"),
                                      p.get("metadata"), os_ctx)
                return {"jsonrpc": "2.0", "id": id_, "result": t.to_json()}
            if method == "tasks/get":
                return {"jsonrpc": "2.0", "id": id_,
                        "result": self.tasks_get(p["id"]).to_json()}
            if method == "tasks/cancel":
                return {"jsonrpc": "2.0", "id": id_, "result": self.cancel(p["id"]).to_json()}
        except ProtoError as exc:
            return {"jsonrpc": "2.0", "id": id_,
                    "error": {"code": -32001, "message": str(exc)}}
        return {"jsonrpc": "2.0", "id": id_,
                "error": {"code": -32601, "message": f"method {method!r} not found"}}


# ---------------------------------------------------------------------------
# AG-UI
# ---------------------------------------------------------------------------
RUN_STARTED, RUN_FINISHED = "RUN_STARTED", "RUN_FINISHED"
TEXT_MESSAGE = "TEXT_MESSAGE_CONTENT"
TOOL_CALL_START, TOOL_CALL_END = "TOOL_CALL_START", "TOOL_CALL_END"
STATE_DELTA = "STATE_DELTA"
HUMAN_INPUT_REQUEST, HUMAN_INPUT_RESULT = "HUMAN_INPUT_REQUEST", "HUMAN_INPUT_RESULT"
ERROR = "ERROR"


class AGUIBus:
    def __init__(self, clock: Clock):
        self.clock = clock
        self._events: dict[str, list[dict]] = {}
        self._subs: dict[str, list] = {}
        self.state: dict[str, dict] = {}

    def emit(self, run_id: str, etype: str, data: dict | None = None) -> dict:
        ev = {"type": etype, "runId": run_id, "ts": self.clock.now(), "data": data or {}}
        self._events.setdefault(run_id, []).append(ev)
        for cb in self._subs.get(run_id, []):
            cb(ev)
        return ev

    def subscribe(self, run_id: str, callback) -> None:
        """Multiple clients (web, mobile, terminal, chat) may subscribe."""
        self._subs.setdefault(run_id, []).append(callback)

    def events(self, run_id: str) -> list[dict]:
        return list(self._events.get(run_id, []))

    def apply_state_delta(self, run_id: str, delta: dict) -> dict:
        st = self.state.setdefault(run_id, {})
        st.update(delta)
        self.emit(run_id, STATE_DELTA, {"delta": delta, "state": dict(st)})
        return dict(st)
