"""Policy, Governance & Safety + AP2-style Mandates.

  - safe_eval: a CEL-like, whitelisted-AST condition language (no eval()).
  - PolicyEngine: four-layer stack (platform > legal > org > user); explicit
    deny overrides; require_approval is a first-class effect; every decision
    is written to the audit chain.
  - MandateStore: Intent, Cart and Payment Mandates as signed first-class
    objects with full chain verification (signatures, linkage, amounts,
    categories, expiry).
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from fnmatch import fnmatch

from .audit import AuditLog
from .canonical import Clock, MandateInvalid, ProtoError, cjson, new_id
from .identity import IdentityService

# ---------------------------------------------------------------------------
# CEL-like safe expression evaluation
# ---------------------------------------------------------------------------
_ALLOWED_NODES = (
    ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub,
    ast.Compare, ast.Name, ast.Load, ast.Constant, ast.List, ast.Tuple,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
)


def safe_eval(expr: str, ctx: dict) -> bool:
    """Evaluate a boolean condition over `ctx` with a strict AST whitelist."""
    tree = ast.parse(expr, mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ProtoError(f"policy expression: disallowed syntax {type(node).__name__!r}")

    def ev(node):
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, (ast.List, ast.Tuple)):
            return [ev(e) for e in node.elts]
        if isinstance(node, ast.Name):
            if node.id in ctx:
                return ctx[node.id]
            raise ProtoError(f"policy expression: unknown variable {node.id!r}")
        if isinstance(node, ast.UnaryOp):
            v = ev(node.operand)
            return (not v) if isinstance(node.op, ast.Not) else -v
        if isinstance(node, ast.BoolOp):
            vals = [ev(v) for v in node.values]
            return all(vals) if isinstance(node.op, ast.And) else any(vals)
        if isinstance(node, ast.Compare):
            left = ev(node.left)
            for op, comp in zip(node.ops, node.comparators):
                right = ev(comp)
                ok = (
                    left == right if isinstance(op, ast.Eq) else
                    left != right if isinstance(op, ast.NotEq) else
                    left < right if isinstance(op, ast.Lt) else
                    left <= right if isinstance(op, ast.LtE) else
                    left > right if isinstance(op, ast.Gt) else
                    left >= right if isinstance(op, ast.GtE) else
                    left in right if isinstance(op, ast.In) else
                    left not in right if isinstance(op, ast.NotIn) else None
                )
                if ok is None:
                    raise ProtoError("policy expression: unsupported comparator")
                if not ok:
                    return False
                left = right
            return True
        raise ProtoError(f"policy expression: unsupported node {type(node).__name__!r}")

    return bool(ev(tree))


# ---------------------------------------------------------------------------
# Policy engine
# ---------------------------------------------------------------------------
LAYERS = ("platform", "legal", "org", "user")
EFFECTS = ("allow", "deny", "require_approval")


@dataclass
class Rule:
    id: str
    layer: str
    effect: str
    actions: list[str]
    condition: str | None = None
    priority: int = 0
    description: str = ""

    def matches(self, action: str, ctx: dict) -> bool:
        if not any(fnmatch(action, pat) for pat in self.actions):
            return False
        if self.condition is None:
            return True
        return safe_eval(self.condition, ctx)


@dataclass
class Decision:
    effect: str
    action: str
    matched: list[str] = field(default_factory=list)
    reason: str = ""

    @property
    def allowed(self) -> bool:
        return self.effect == "allow"


class PolicyEngine:
    """Four-layer, deny-overrides policy evaluation on every sensitive action."""

    SENSITIVE_DEFAULT_DENY = (
        "payment.*", "wallet.*", "delegate", "mandate.verify_bypass", "killswitch.*",
    )

    def __init__(self, audit: AuditLog):
        self.audit = audit
        self.rules: list[Rule] = []
        self._defaults: list[tuple[str, str]] = [(p, "deny") for p in self.SENSITIVE_DEFAULT_DENY]

    def add_rule(self, layer: str, effect: str, actions: list[str], condition: str | None = None,
                 priority: int = 0, description: str = "", rule_id: str | None = None) -> Rule:
        if layer not in LAYERS:
            raise ProtoError(f"unknown policy layer {layer!r}")
        if effect not in EFFECTS:
            raise ProtoError(f"unknown effect {effect!r}")
        r = Rule(rule_id or new_id("rule"), layer, effect, list(actions), condition,
                 priority, description)
        self.rules.append(r)
        self.audit.append("policy-engine", "policy.rule_added",
                          {"rule": r.id, "layer": layer, "effect": effect, "actions": actions,
                           "condition": condition})
        return r

    def set_default(self, action_pattern: str, effect: str) -> None:
        self._defaults.insert(0, (action_pattern, effect))

    def _default_for(self, action: str) -> str:
        for pat, eff in self._defaults:
            if fnmatch(action, pat):
                return eff
        return "allow"

    def evaluate(self, action: str, ctx: dict, actor: str = "?") -> Decision:
        matched = [r for r in self.rules if r.matches(action, ctx)]
        matched.sort(key=lambda r: (LAYERS.index(r.layer), -r.priority))
        denies = [r for r in matched if r.effect == "deny"]
        approvals = [r for r in matched if r.effect == "require_approval"]
        allows = [r for r in matched if r.effect == "allow"]
        if denies:
            d = Decision("deny", action, [r.id for r in matched],
                         f"denied by {denies[0].layer} rule {denies[0].id}")
        elif approvals:
            d = Decision("require_approval", action, [r.id for r in matched],
                         f"approval required by {approvals[0].layer} rule {approvals[0].id}")
        elif allows:
            d = Decision("allow", action, [r.id for r in matched],
                         f"allowed by {allows[0].layer} rule {allows[0].id}")
        else:
            eff = self._default_for(action)
            d = Decision(eff, action, [], f"default:{eff}")
        self.audit.append(actor, "policy.decision",
                          {"action": action, "effect": d.effect, "matched": d.matched,
                           "reason": d.reason,
                           "ctx_keys": sorted(k for k in ctx.keys())})
        return d


# ---------------------------------------------------------------------------
# AP2-style mandates
# ---------------------------------------------------------------------------
class MandateStore:
    def __init__(self, ids: IdentityService, audit: AuditLog, clock: Clock):
        self.ids = ids
        self.audit = audit
        self.clock = clock
        self._store: dict[str, dict] = {}

    def _sign(self, mtype: str, signer_did: str, payload: dict) -> dict:
        body = {"type": mtype, "id": new_id(mtype.lower().replace("mandate", "mnd")),
                "created": self.clock.now(), "signer": signer_did, "payload": payload}
        m = {**body, "sig": self.ids.sign_as(signer_did, body)}
        self._store[m["id"]] = m
        self.audit.append(signer_did, "mandate.issued",
                          {"mandate": m["id"], "type": mtype, "payload": payload})
        return m

    def get(self, mandate_id: str) -> dict:
        if mandate_id not in self._store:
            raise MandateInvalid(f"unknown mandate {mandate_id}")
        return self._store[mandate_id]

    def verify_signature(self, m: dict) -> bool:
        body = {k: v for k, v in m.items() if k != "sig"}
        return self.ids.verify_for(m["signer"], m["sig"], body)

    # -- issuance -------------------------------------------------------------
    def issue_intent(self, user_did: str, intent: str, max_amount: float, currency: str,
                     categories: list[str] | None = None, ttl: float = 3600.0) -> dict:
        return self._sign("IntentMandate", user_did, {
            "user": user_did, "intent": intent, "max_amount": float(max_amount),
            "currency": currency, "categories": categories,
            "expires": self.clock.now() + ttl,
        })

    def issue_cart(self, merchant_did: str, intent_id: str, items: list[dict], total: float,
                   currency: str, agent_did: str | None = None) -> dict:
        return self._sign("CartMandate", merchant_did, {
            "merchant": merchant_did, "intent_id": intent_id, "items": items,
            "total": round(float(total), 2), "currency": currency, "agent": agent_did,
        })

    def issue_payment(self, payer_did: str, cart_id: str, amount: float, currency: str,
                      rail: str, payee_did: str) -> dict:
        return self._sign("PaymentMandate", payer_did, {
            "payer": payer_did, "cart_id": cart_id, "amount": round(float(amount), 2),
            "currency": currency, "rail": rail, "payee": payee_did,
        })

    # -- verification ----------------------------------------------------------
    def verify_chain(self, payment_id: str) -> tuple[bool, str]:
        """Payment -> Cart -> Intent: signatures, linkage, amounts, categories,
        currency and expiry must all hold."""
        try:
            pay = self.get(payment_id)
            if pay["type"] != "PaymentMandate":
                return False, "not-a-payment-mandate"
            if not self.verify_signature(pay):
                return False, "payment-signature-invalid"
            cart = self.get(pay["payload"]["cart_id"])
            if cart["type"] != "CartMandate" or not self.verify_signature(cart):
                return False, "cart-invalid"
            if round(cart["payload"]["total"], 2) != round(pay["payload"]["amount"], 2):
                return False, "amount-mismatch"
            if cart["payload"]["currency"] != pay["payload"]["currency"]:
                return False, "currency-mismatch"
            intent = self.get(cart["payload"]["intent_id"])
            if intent["type"] != "IntentMandate" or not self.verify_signature(intent):
                return False, "intent-invalid"
            ip = intent["payload"]
            if ip["expires"] < self.clock.now():
                return False, "intent-expired"
            if pay["payload"]["payer"] != ip["user"]:
                return False, "payer-mismatch"
            if pay["payload"]["amount"] > ip["max_amount"] + 1e-9:
                return False, "exceeds-intent-max"
            if ip["currency"] != pay["payload"]["currency"]:
                return False, "currency-mismatch"
            cats = ip.get("categories")
            if cats is not None:
                for item in cart["payload"]["items"]:
                    if item.get("category") not in cats:
                        return False, f"category-not-authorized:{item.get('category')}"
            self.audit.append("mandate-store", "mandate.chain_verified",
                              {"payment": payment_id, "cart": cart["id"], "intent": intent["id"]})
            return True, "ok"
        except MandateInvalid as exc:
            return False, str(exc)
