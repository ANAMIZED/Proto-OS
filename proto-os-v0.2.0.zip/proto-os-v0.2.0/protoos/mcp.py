"""MCP adapter (reference-shaped, in-process JSON-RPC 2.0).

  - MCPServer / MCPClient: initialize, tools/list, tools/call.
  - Paid tools: a tool with a price answers with a 402-coded JSON-RPC error
    carrying an x402 challenge; retry with a verified receipt succeeds.
  - MCPMux: federation of multiple MCP servers behind namespaced tool names.
  - openapi_to_mcp: automatic OpenAPI -> MCP tool conversion (offline
    transport by default because container egress is disabled).
  - ResourceCache: resource/prompt caching with policy-based access control.

Conformance note: wire shapes follow the MCP JSON-RPC pattern but this
offline build is not certified against the published spec version.
"""
from __future__ import annotations

import time
from collections import OrderedDict

from .audit import AuditLog
from .canonical import ProtoError, new_id
from .policy import PolicyEngine

PROTOCOL_VERSION = "2025-06-18"
ERR_PAYMENT_REQUIRED = 402
ERR_METHOD_NOT_FOUND = -32601
ERR_INVALID_PARAMS = -32602
ERR_TOOL = -32000


def _resp(id_, result=None, error=None):
    out = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        out["error"] = error
    else:
        out["result"] = result
    return out


class MCPServer:
    def __init__(self, name: str, version: str = "0.1.0", x402_rail=None,
                 payee_did: str = "", payment_verifier=None):
        self.name, self.version = name, version
        self.x402 = x402_rail
        self.payee_did = payee_did
        self.payment_verifier = payment_verifier  # (receipt, resource, min_amount) -> bool
        self._tools: dict[str, dict] = {}

    def add_tool(self, name: str, description: str, input_schema: dict, handler,
                 price: float | None = None, currency: str = "USD",
                 annotations: dict | None = None) -> None:
        self._tools[name] = {
            "name": name, "description": description, "inputSchema": input_schema,
            "handler": handler, "price": price, "currency": currency,
            "annotations": annotations or {},
        }

    def tool_defs(self) -> list[dict]:
        out = []
        for t in self._tools.values():
            d = {"name": t["name"], "description": t["description"],
                 "inputSchema": t["inputSchema"], "annotations": t["annotations"]}
            if t["price"]:
                d["annotations"] = {**d["annotations"],
                                    "price": t["price"], "currency": t["currency"]}
            out.append(d)
        return out

    def handle(self, req: dict) -> dict:
        method, id_, params = req.get("method"), req.get("id"), req.get("params") or {}
        if method == "initialize":
            return _resp(id_, {
                "protocolVersion": PROTOCOL_VERSION,
                "serverInfo": {"name": self.name, "version": self.version},
                "capabilities": {"tools": {"listChanged": False}},
            })
        if method == "tools/list":
            return _resp(id_, {"tools": self.tool_defs()})
        if method == "tools/call":
            name = params.get("name")
            tool = self._tools.get(name)
            if tool is None:
                return _resp(id_, error={"code": ERR_INVALID_PARAMS,
                                         "message": f"unknown tool {name!r}"})
            args = params.get("arguments") or {}
            if tool["price"]:
                receipt = params.get("_meta", {}).get("payment_receipt")
                resource = f"mcp:{self.name}/{name}"
                verify = self.payment_verifier or (
                    self.x402.verify_receipt if self.x402 else None)
                if not (receipt and verify and verify(receipt, resource, tool["price"])):
                    ch = (self.x402.challenge(resource, tool["price"], tool["currency"],
                                              self.payee_did)
                          if self.x402 else {"amount": tool["price"]})
                    return _resp(id_, error={"code": ERR_PAYMENT_REQUIRED,
                                             "message": "payment required",
                                             "data": {"challenge": ch}})
            try:
                result = tool["handler"](**args)
            except TypeError as exc:
                return _resp(id_, error={"code": ERR_INVALID_PARAMS, "message": str(exc)})
            except Exception as exc:  # tool error surfaced, not crashed
                return _resp(id_, error={"code": ERR_TOOL,
                                         "message": f"{type(exc).__name__}: {exc}"})
            return _resp(id_, {
                "content": [{"type": "text", "text": str(result)}],
                "structuredContent": result if isinstance(result, (dict, list)) else
                {"value": result},
                "isError": False,
            })
        return _resp(id_, error={"code": ERR_METHOD_NOT_FOUND,
                                 "message": f"method {method!r} not found"})


class MCPClient:
    def __init__(self, transport):
        """`transport` is a callable(request_dict) -> response_dict; in-process
        this is server.handle, over HTTP it posts JSON-RPC."""
        self.transport = transport
        self._n = 0

    def _req(self, method: str, params: dict | None = None) -> dict:
        self._n += 1
        return self.transport({"jsonrpc": "2.0", "id": self._n, "method": method,
                               "params": params or {}})

    def initialize(self) -> dict:
        return self._req("initialize")["result"]

    def list_tools(self) -> list[dict]:
        return self._req("tools/list")["result"]["tools"]

    def call(self, name: str, arguments: dict, receipt: dict | None = None) -> dict:
        params = {"name": name, "arguments": arguments}
        if receipt:
            params["_meta"] = {"payment_receipt": receipt}
        return self._req("tools/call", params)


class MCPMux:
    """Federate multiple MCP servers behind namespaced tool names."""

    def __init__(self):
        self._servers: dict[str, MCPServer] = {}

    def mount(self, prefix: str, server: MCPServer) -> None:
        self._servers[prefix] = server

    def servers(self) -> dict[str, MCPServer]:
        return dict(self._servers)

    def list_tools(self) -> list[dict]:
        out = []
        for prefix, srv in self._servers.items():
            for t in srv.tool_defs():
                out.append({**t, "name": f"{prefix}.{t['name']}", "server": prefix})
        return out

    def handle(self, req: dict) -> dict:
        method = req.get("method")
        if method == "tools/list":
            return _resp(req.get("id"), {"tools": self.list_tools()})
        if method == "tools/call":
            full = (req.get("params") or {}).get("name", "")
            if "." not in full:
                return _resp(req.get("id"), error={"code": ERR_INVALID_PARAMS,
                                                   "message": "expected '<server>.<tool>'"})
            prefix, name = full.split(".", 1)
            srv = self._servers.get(prefix)
            if srv is None:
                return _resp(req.get("id"), error={"code": ERR_INVALID_PARAMS,
                                                   "message": f"unknown server {prefix!r}"})
            inner = {**req, "params": {**req["params"], "name": name}}
            return srv.handle(inner)
        if method == "initialize":
            return _resp(req.get("id"), {"protocolVersion": PROTOCOL_VERSION,
                                         "serverInfo": {"name": "proto-mux", "version": "0.1.0"},
                                         "capabilities": {"tools": {}}})
        return _resp(req.get("id"), error={"code": ERR_METHOD_NOT_FOUND,
                                           "message": f"method {method!r} not found"})


def openapi_to_mcp(spec: dict, transport=None, server_name: str | None = None) -> MCPServer:
    """Convert an OpenAPI document into an MCP server.

    `transport(method, url, args) -> result` performs the actual HTTP call;
    with egress disabled the default offline transport returns a structured
    simulated response describing the request it would have made."""
    title = (spec.get("info") or {}).get("title", "openapi")
    base = (spec.get("servers") or [{"url": ""}])[0].get("url", "")
    srv = MCPServer(server_name or f"openapi:{title}")

    def offline_transport(method, url, args):
        return {"simulated": True, "method": method.upper(), "url": url, "args": args,
                "note": "container egress disabled; enable network settings for live calls"}

    tx = transport or offline_transport
    for path, ops in (spec.get("paths") or {}).items():
        for method, op in ops.items():
            if method.lower() not in ("get", "post", "put", "delete", "patch"):
                continue
            op_id = op.get("operationId") or f"{method}_{path.strip('/').replace('/', '_') or 'root'}"
            props, required = {}, []
            for p in op.get("parameters", []):
                props[p["name"]] = {"type": p.get("schema", {}).get("type", "string"),
                                    "description": p.get("description", "")}
                if p.get("required"):
                    required.append(p["name"])
            body = (op.get("requestBody", {}).get("content", {})
                    .get("application/json", {}).get("schema", {}))
            for name, sch in (body.get("properties") or {}).items():
                props[name] = {"type": sch.get("type", "string"),
                               "description": sch.get("description", "")}
            required += body.get("required", [])
            url = base + path

            def make_handler(m=method, u=url):
                def handler(**kwargs):
                    return tx(m, u, kwargs)
                return handler

            srv.add_tool(op_id, op.get("summary") or op.get("description") or op_id,
                         {"type": "object", "properties": props,
                          "required": sorted(set(required))},
                         make_handler(),
                         annotations={"readOnlyHint": method.lower() == "get",
                                      "openWorldHint": True})
    return srv


class ResourceCache:
    """Resource & prompt cache with policy-based access control."""

    def __init__(self, engine: PolicyEngine, audit: AuditLog, maxsize: int = 256):
        self.engine, self.audit = engine, audit
        self.maxsize = maxsize
        self._data: OrderedDict[str, tuple[str, object]] = OrderedDict()

    def put(self, key: str, value, scope: str = "public") -> None:
        self._data[key] = (scope, value)
        self._data.move_to_end(key)
        while len(self._data) > self.maxsize:
            self._data.popitem(last=False)

    def get(self, key: str, requester: str, requester_scopes: list[str]):
        if key not in self._data:
            return None
        scope, value = self._data[key]
        decision = self.engine.evaluate(
            "cache.read", {"key": key, "scope": scope, "requester": requester,
                           "requester_scopes": requester_scopes}, actor=requester)
        if decision.effect != "allow":
            self.audit.append(requester, "cache.denied", {"key": key, "scope": scope})
            return None
        self._data.move_to_end(key)
        return value
