"""Constellation: the live object graph of a ProtoOS world.

Mirrors the web console's Constellation view: nodes are principals, budgets,
MCP servers/tools, AP2 mandates, receipts, tasks, and pending approvals;
edges are structure, ownership, delegation, mandate chains, and money flow.

Exports: JSON (nodes/edges/positions), Graphviz DOT, and a standalone SVG
snapshot rendered in the ledger-room palette. The force layout is a pure,
seeded function, so identical worlds produce identical constellations.

CLI:  python3 -m protoos.graph [out_dir]
"""
from __future__ import annotations

import json
import math
import random
from xml.sax.saxutils import escape as _x

NODE_TYPES = ("id", "bud", "srv", "tool", "mnd", "rcp", "task", "appr")
EDGE_KINDS = ("struct", "own", "vc", "chain", "money")
DEFAULT_INCLUDE = frozenset({"mandates", "receipts", "tasks", "tools"})

PAL = {"user": "#2F5D50", "agent": "#1E2A24", "service": "#5A665C",
       "merchant": "#8a6d1a", "org": "#5A665C",
       "intent": "#CDBF95", "cart": "#5A665C", "payment": "#2F5D50",
       "rcp": "#2F5D50", "task": "#1E2A24", "appr": "#B23A2B",
       "srv": "#5A665C", "tool": "#5A665C",
       "edge": "#5A665C", "chain": "#1E2A24", "money": "#2F5D50",
       "vc": "#8a6d1a", "paper": "#F7FAF2", "manila": "#E9DFC2",
       "ink": "#1E2A24", "warn": "#B23A2B"}


# --------------------------------------------------------------------------
# graph construction
# --------------------------------------------------------------------------
def build_graph(os_, include: frozenset = DEFAULT_INCLUDE) -> dict:
    """Derive the constellation from a live ProtoOS instance."""
    nodes: list[dict] = []
    edges: list[dict] = []

    def add(**n):
        nodes.append(n)

    def link(a, b, kind):
        edges.append({"a": a, "b": b, "kind": kind})

    idents = dict(os_.ids._identities)
    for ident in idents.values():
        add(key=ident.did, type="id", sub=ident.kind, label=ident.name)

    budgets = dict(os_.wallet.budgets)
    for b in budgets.values():
        spent = os_.wallet.spent(b.id)
        add(key=b.id, type="bud", label=f"budget {b.id[-4:]}",
            limit=b.limit_total, spent=round(spent, 2),
            deny=list(b.categories_deny or []))
        if b.parent:
            link(b.id, b.parent, "struct")
        if b.owner in idents:
            link(b.owner, b.id, "own")

    # delegation edges: a child budget owned by a different principal than its
    # parent's owner is a granted slice (the trust relationship the web view
    # draws from VCs).
    seen_vc = set()
    for b in budgets.values():
        if not b.parent:
            continue
        p = budgets.get(b.parent)
        if p and p.owner != b.owner and p.owner in idents and b.owner in idents:
            k = (p.owner, b.owner)
            if k not in seen_vc:
                seen_vc.add(k)
                link(p.owner, b.owner, "vc")

    if "tools" in include:
        for prefix, srv in os_.mcp.servers().items():
            skey = f"srv:{prefix}"
            add(key=skey, type="srv", label=prefix)
            for tname, t in srv._tools.items():
                tkey = f"tool:{prefix}.{tname}"
                add(key=tkey, type="tool", label=f"{prefix}.{tname}",
                    paid=bool(t.get("price")))
                link(tkey, skey, "struct")

    if "mandates" in include:
        store = dict(os_.mandates._store)
        intents = sorted((m for m in store.values() if m["type"] == "IntentMandate"),
                         key=lambda m: m["created"])[-8:]
        keep = {m["id"] for m in intents}
        for m in store.values():
            if m["type"] == "CartMandate" and m["payload"].get("intent_id") in keep:
                keep.add(m["id"])
        for m in store.values():
            if m["type"] == "PaymentMandate" and m["payload"].get("cart_id") in keep:
                keep.add(m["id"])
        for m in store.values():
            if m["id"] not in keep:
                continue
            sub = {"IntentMandate": "intent", "CartMandate": "cart",
                   "PaymentMandate": "payment"}[m["type"]]
            add(key=m["id"], type="mnd", sub=sub, label=sub)
            p = m["payload"]
            if sub == "intent" and p.get("user") in idents:
                link(p["user"], m["id"], "chain")
            elif sub == "cart":
                if p.get("intent_id") in store:
                    link(p["intent_id"], m["id"], "chain")
                if p.get("merchant") in idents:
                    link(p["merchant"], m["id"], "chain")
            elif sub == "payment":
                if p.get("cart_id") in store:
                    link(p["cart_id"], m["id"], "chain")

    if "receipts" in include:
        receipts = []
        for rail in os_.wallet.rails.values():
            receipts.extend(getattr(rail, "_receipts", {}).values())
        receipts.sort(key=lambda r: r.ts, reverse=True)
        ledger_by_ref = {e.get("ref"): e for e in os_.wallet.ledger}
        for r in receipts[:12]:
            key = f"r:{r.receipt_id}"
            add(key=key, type="rcp", label=f"${r.amount:.2f}", rail=r.rail)
            if r.payer in idents:
                link(r.payer, key, "money")
            if r.payee in idents:
                link(key, r.payee, "money")
            led = ledger_by_ref.get(r.receipt_id)
            if led and led.get("budget") in budgets:
                link(key, led["budget"], "money")

    if "tasks" in include:
        tasks = sorted(os_.a2a.tasks.values(), key=lambda t: t.updated,
                       reverse=True)[:8]
        for t in tasks:
            add(key=t.id, type="task", sub=t.state, label="task")
            if t.agent in idents:
                link(t.agent, t.id, "struct")

    for aid, rec in os_._approvals.items():
        if rec.get("status") != "pending":
            continue
        ctx = rec.get("ctx", {})
        amt = ctx.get("amount")
        add(key=aid, type="appr",
            label=f"${amt:.2f}" if isinstance(amt, (int, float)) else "approval")
        if rec.get("actor") in idents:
            link(rec["actor"], aid, "chain")
        if ctx.get("budget") in budgets:
            link(aid, ctx["budget"], "chain")

    keys = {n["key"] for n in nodes}
    edges = [e for e in edges if e["a"] in keys and e["b"] in keys]
    return {"nodes": nodes, "edges": edges}


# --------------------------------------------------------------------------
# deterministic force layout (same physics as the web console)
# --------------------------------------------------------------------------
_REST = {"struct": 60.0, "vc": 92.0, "money": 52.0, "own": 58.0, "chain": 38.0}


def layout(graph: dict, iterations: int = 300, seed: int = 7) -> dict:
    rnd = random.Random(seed)
    pos = {n["key"]: [rnd.uniform(-60, 60), rnd.uniform(-60, 60)]
           for n in graph["nodes"]}
    vel = {k: [0.0, 0.0] for k in pos}
    keys = list(pos.keys())
    alpha = 0.55
    for _ in range(iterations):
        if alpha <= 0.004:
            break
        alpha *= 0.986
        force = {k: [-pos[k][0] * 0.02, -pos[k][1] * 0.02] for k in keys}
        for i in range(len(keys)):
            ki = keys[i]
            xi, yi = pos[ki]
            for j in range(i + 1, len(keys)):
                kj = keys[j]
                dx = pos[kj][0] - xi
                dy = pos[kj][1] - yi
                d2 = dx * dx + dy * dy
                if d2 > 72900.0:
                    continue
                if d2 < 1.0:
                    d2 = 1.0
                f = 1600.0 / d2
                dl = math.sqrt(d2)
                ux, uy = dx / dl, dy / dl
                force[ki][0] -= ux * f
                force[ki][1] -= uy * f
                force[kj][0] += ux * f
                force[kj][1] += uy * f
        for e in graph["edges"]:
            a, b = e["a"], e["b"]
            rest = _REST.get(e["kind"], 50.0)
            dx = pos[b][0] - pos[a][0]
            dy = pos[b][1] - pos[a][1]
            dl = max(1.0, math.hypot(dx, dy))
            f = (dl - rest) * 0.035
            ux, uy = dx / dl, dy / dl
            force[a][0] += ux * f
            force[a][1] += uy * f
            force[b][0] -= ux * f
            force[b][1] -= uy * f
        for k in keys:
            vx = (vel[k][0] + force[k][0] * alpha * 2.1) * 0.85
            vy = (vel[k][1] + force[k][1] * alpha * 2.1) * 0.85
            vx = max(-12.0, min(12.0, vx))
            vy = max(-12.0, min(12.0, vy))
            vel[k] = [vx, vy]
            pos[k][0] += vx
            pos[k][1] += vy
    return {k: (round(v[0], 3), round(v[1], 3)) for k, v in pos.items()}


# --------------------------------------------------------------------------
# exports
# --------------------------------------------------------------------------
def to_json(graph: dict, pos: dict | None = None) -> str:
    out = {"nodes": graph["nodes"], "edges": graph["edges"]}
    if pos:
        out["positions"] = {k: list(v) for k, v in pos.items()}
    return json.dumps(out, indent=1, sort_keys=True)


def to_dot(graph: dict) -> str:
    shape = {"id": "circle", "bud": "box", "srv": "component", "tool": "ellipse",
             "mnd": "point", "rcp": "note", "task": "hexagon", "appr": "doublecircle"}
    lines = ["digraph proto {", '  bgcolor="#ECF1E4";',
             '  node [fontname="Helvetica", fontsize=9];']
    for n in graph["nodes"]:
        lines.append('  "%s" [label="%s", shape=%s];'
                     % (n["key"], n["label"].replace('"', "'"),
                        shape.get(n["type"], "ellipse")))
    for e in graph["edges"]:
        style = "dashed" if e["kind"] == "vc" else "solid"
        lines.append('  "%s" -> "%s" [style=%s, color="%s"];'
                     % (e["a"], e["b"], style, PAL.get(e["kind"], PAL["edge"])))
    lines.append("}")
    return "\n".join(lines)


def _node_svg(n: dict, x: float, y: float) -> str:
    t = n["type"]
    if t == "id":
        c = PAL.get(n.get("sub", "agent"), PAL["agent"])
        init = _x((n["label"][:1] or "?").upper())
        return (f'<circle cx="{x}" cy="{y}" r="13" fill="{c}"/>' 
                f'<text x="{x}" y="{y+3.5}" text-anchor="middle" font-size="10"'
                f' font-weight="bold" fill="{PAL["paper"]}">{init}</text>'
                f'<text x="{x}" y="{y+26}" text-anchor="middle" font-size="9"'
                f' fill="{PAL["ink"]}">{_x(n["label"][:18])}</text>')
    if t == "bud":
        frac = 0.0
        if n.get("limit"):
            frac = max(0.0, min(1.0, n.get("spent", 0.0) / n["limit"]))
        fill = PAL["warn"] if frac >= 0.85 else PAL["payment"]
        h = 22 * frac
        return (f'<rect x="{x-11}" y="{y-11}" width="22" height="22"'
                f' fill="{PAL["paper"]}" stroke="{PAL["ink"]}" stroke-width="1.3"/>'
                f'<rect x="{x-11}" y="{y+11-h}" width="22" height="{h}" fill="{fill}"/>'
                f'<rect x="{x-11}" y="{y-11}" width="22" height="22" fill="none"'
                f' stroke="{PAL["ink"]}" stroke-width="1.3"/>'
                f'<text x="{x}" y="{y+24}" text-anchor="middle" font-size="8.5"'
                f' fill="{PAL["ink"]}">{_x(n["label"])}</text>')
    if t == "srv":
        return (f'<rect x="{x-11}" y="{y-8}" width="22" height="16" fill="none"'
                f' stroke="{PAL["srv"]}" stroke-width="1.3"/>'
                f'<circle cx="{x}" cy="{y}" r="1.6" fill="{PAL["srv"]}"/>'
                f'<text x="{x}" y="{y+21}" text-anchor="middle" font-size="8.5"'
                f' fill="{PAL["ink"]}">{_x(n["label"])}</text>')
    if t == "tool":
        fill = PAL["manila"] if n.get("paid") else PAL["paper"]
        return (f'<circle cx="{x}" cy="{y}" r="7" fill="{fill}"'
                f' stroke="{PAL["tool"]}" stroke-width="1.2"/>')
    if t == "mnd":
        sub = n.get("sub", "intent")
        fill = {"intent": PAL["intent"], "cart": PAL["paper"],
                "payment": "#DDE9E1"}[sub]
        stroke = PAL["payment"] if sub == "payment" else PAL["cart"]
        return (f'<circle cx="{x}" cy="{y}" r="5" fill="{fill}"'
                f' stroke="{stroke}" stroke-width="1.1"/>')
    if t == "rcp":
        return (f'<rect x="{x-8}" y="{y-5}" width="16" height="10"'
                f' fill="{PAL["paper"]}" stroke="{PAL["rcp"]}" stroke-width="1.2"/>'
                f'<path d="M {x-4} {y} l 3 3 l 6 -6" fill="none"'
                f' stroke="{PAL["rcp"]}" stroke-width="1.2"/>')
    if t == "task":
        st = n.get("sub", "submitted")
        fill = {"completed": "#DDE9E1", "input-required": PAL["manila"]}.get(
            st, PAL["paper"])
        stroke = PAL["warn"] if st in ("canceled", "failed") else PAL["ink"]
        return (f'<circle cx="{x}" cy="{y}" r="8" fill="{fill}"'
                f' stroke="{stroke}" stroke-width="1.3"/>')
    if t == "appr":
        return (f'<circle cx="{x}" cy="{y}" r="10" fill="{PAL["manila"]}"'
                f' stroke="{PAL["appr"]}" stroke-width="1.6"/>'
                f'<circle cx="{x}" cy="{y}" r="13" fill="none"'
                f' stroke="{PAL["appr"]}" stroke-width="1.2"'
                f' stroke-dasharray="3 3"/>')
    return f'<circle cx="{x}" cy="{y}" r="5" fill="{PAL["ink"]}"/>'


def to_svg(graph: dict, pos: dict, width: int = 900, height: int = 620) -> str:
    xs = [p[0] for p in pos.values()] or [0]
    ys = [p[1] for p in pos.values()] or [0]
    minx, maxx = min(xs) - 40, max(xs) + 40
    miny, maxy = min(ys) - 40, max(ys) + 40
    sx = (width - 20) / max(80.0, maxx - minx)
    sy = (height - 20) / max(80.0, maxy - miny)
    s = min(sx, sy, 2.0)

    def P(k):
        x, y = pos[k]
        return (10 + (x - minx) * s, 10 + (y - miny) * s)

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}"'
           f' height="{height}" viewBox="0 0 {width} {height}">',
           f'<desc>Proto constellation: {len(graph["nodes"])} nodes,'
           f' {len(graph["edges"])} edges</desc>',
           f'<rect width="100%" height="100%" fill="#ECF1E4"/>']
    for e in graph["edges"]:
        (x1, y1), (x2, y2) = P(e["a"]), P(e["b"])
        col = PAL.get(e["kind"], PAL["edge"])
        w = 1.7 if e["kind"] == "money" else 1.1
        dash = ' stroke-dasharray="4 3"' if e["kind"] == "vc" else (
            ' stroke-dasharray="2 3"' if e["kind"] == "own" else "")
        out.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}"'
                   f' y2="{y2:.1f}" stroke="{col}" stroke-width="{w}"'
                   f' opacity="0.55"{dash}/>')
    order = {"mnd": 0, "rcp": 1, "tool": 2, "task": 3, "appr": 4, "srv": 5,
             "bud": 6, "id": 7}
    for n in sorted(graph["nodes"], key=lambda n: order.get(n["type"], 0)):
        x, y = P(n["key"])
        out.append(_node_svg(n, round(x, 1), round(y, 1)))
    out.append("</svg>")
    return "\n".join(out)


# --------------------------------------------------------------------------
# shared demo world (mirrors the web console's seed)
# --------------------------------------------------------------------------
def build_demo_world():
    """Seed a small economy exercising every subsystem; returns (os_, refs)."""
    from protoos import Catalog, InputRequired, PendingApproval, ProtoOS

    os_ = ProtoOS()
    org = os_.ids.create_identity("Fieldnotes Co-op", "service")
    ana = os_.create_user("Ana (owner)")
    shop = os_.create_merchant("Northwind Supply")

    b_org = os_.wallet.create_budget(org.did, 500.0,
                                     categories_deny=["surveillance"])
    b_ana = os_.wallet.create_budget(ana.did, 150.0, parent=b_org.id)

    os_.engine.add_rule("platform", "deny", ["payment.settle"],
                        "category == 'surveillance'",
                        description="No surveillance-category purchases")
    os_.engine.add_rule("org", "require_approval", ["payment.settle"],
                        "amount > 50", description="Human approval over $50")
    os_.engine.add_rule("user", "allow", ["payment.settle"],
                        "amount <= 50", description="Auto-allow small purchases")

    def shopper_handler(task, message, os_ctx):
        if "buy" in message.lower() and not task.meta.get("confirmed"):
            task.meta["confirmed"] = True
            raise InputRequired("Task involves spending — confirm budget use?")
        return {"kind": "text", "text": "Budget confirmed; purchase plan drafted."}

    shopper = os_.create_agent("shopper-agent",
                               "Finds and buys goods under mandate.",
                               skills=[{"id": "shopping"}, {"id": "checkout"}],
                               handler=shopper_handler)
    research = os_.create_agent("research-agent",
                                "Summarizes sources; pays per call.",
                                skills=[{"id": "research"}, {"id": "summarize"}],
                                cost={"per_task": 0.10})
    b_shop = os_.wallet.create_budget(shopper.did, 60.0, parent=b_ana.id)
    b_res = os_.wallet.create_budget(research.did, 5.0, parent=b_ana.id)

    srv = os_.make_mcp_server("tools", payee_did=shop.did)
    srv.add_tool("echo", "Echo text back (free).",
                 {"type": "object", "properties": {"t": {"type": "string"}}},
                 lambda t="": {"echo": t})
    srv.add_tool("summarize", "Summarize text (paid).",
                 {"type": "object", "properties": {"t": {"type": "string"}}},
                 lambda t="": {"summary": (t or "")[:40] + "…"}, price=0.10)
    os_.mount_mcp("tools", srv)

    catalog = Catalog(shop.did, "Northwind Supply")
    catalog.add("NW-CBL", "USB-C cable 2m", 18.0, "USD", "electronics")
    catalog.add("NW-HDP", "Quiet headphones", 129.0, "USD", "electronics")
    catalog.add("NW-CAM", "Mini tracker cam", 59.0, "USD", "surveillance")
    catalog.add("NW-LMP", "Desk lamp", 42.0, "USD", "home")

    # free + paid tool (auto x402 under the research slice)
    os_.call_tool(research.did, "tools.echo", {"t": "ping"})
    os_.call_tool(research.did, "tools.summarize",
                  {"t": "mandate chains bind intent to payment"},
                  budget_id=b_res.id)

    # small purchase: auto-allow, traditional rail
    os_.purchase(ana.did, catalog, [{"sku": "NW-CBL", "qty": 1}],
                 "Buy a spare cable", 18.0, b_shop.id, rail="traditional",
                 agent_did=shopper.did)

    # large purchase: parks for approval, then Ana approves (settles on x402)
    pend = os_.purchase(ana.did, catalog, [{"sku": "NW-HDP", "qty": 1}],
                        "Buy quiet headphones", 129.0, b_ana.id, rail="x402",
                        agent_did=shopper.did)
    assert isinstance(pend, PendingApproval)
    os_.approve(pend.approval_id, ana.did, True)

    # blocked category, two layers deep:
    # (a) charged to the co-op tree -> the budget's category block trips first
    budget_blocked = False
    try:
        os_.purchase(ana.did, catalog, [{"sku": "NW-CAM", "qty": 1}],
                     "Buy tracker cam", 59.0, b_shop.id, rail="traditional",
                     agent_did=shopper.did)
    except Exception as exc:
        budget_blocked = type(exc).__name__ == "BudgetExceeded"
    assert budget_blocked, "co-op budget should block surveillance category"
    # (b) charged to unrestricted petty cash -> platform policy deny fires
    b_petty = os_.wallet.create_budget(ana.did, 80.0)
    policy_blocked = False
    try:
        os_.purchase(ana.did, catalog, [{"sku": "NW-CAM", "qty": 1}],
                     "Buy tracker cam", 59.0, b_petty.id, rail="traditional",
                     agent_did=shopper.did)
    except Exception as exc:
        policy_blocked = type(exc).__name__ == "PolicyDenied"
    assert policy_blocked, "platform policy should deny surveillance purchase"

    # a second approval left pending so the constellation shows one waiting
    pend2 = os_.purchase(ana.did, catalog, [{"sku": "NW-LMP", "qty": 2}],
                         "Two desk lamps", 84.0, b_org.id, rail="traditional",
                         agent_did=shopper.did)
    assert isinstance(pend2, PendingApproval)

    # A2A task with human input-required, then resumed
    t = os_.a2a.message_send(shopper.did, "Please buy a field notebook")
    assert t.state == "input-required"
    os_.a2a.provide_input(t.id, "yes, go ahead and buy it")

    refs = {"org": org, "ana": ana, "shop": shop, "shopper": shopper,
            "research": research, "budgets": [b_org, b_ana, b_shop, b_res, b_petty],
            "catalog": catalog, "pending": pend2, "task": t}
    return os_, refs


def main(argv: list[str]) -> int:
    from pathlib import Path
    out = Path(argv[1]) if len(argv) > 1 else Path("constellation_out")
    out.mkdir(parents=True, exist_ok=True)
    os_, _ = build_demo_world()
    g = build_graph(os_)
    pos = layout(g)
    (out / "constellation.json").write_text(to_json(g, pos))
    (out / "constellation.dot").write_text(to_dot(g))
    (out / "constellation.svg").write_text(to_svg(g, pos))
    print(f"constellation: {len(g['nodes'])} nodes, {len(g['edges'])} edges"
          f" -> {out}/constellation.{{json,dot,svg}}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    import sys
    sys.exit(main(sys.argv))
