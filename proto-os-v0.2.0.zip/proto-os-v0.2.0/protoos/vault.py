"""Obsidian vault export: write a ProtoOS world as linked markdown notes.

Every identity, budget, mandate, receipt, and task becomes a note; policy
rules and decisions, the hash-chained audit log, and the AG-UI feed become
tables. Notes reference each other with [[wikilinks]], so Obsidian's graph
view reproduces the constellation natively.

CLI:  python3 -m protoos.vault [out.zip | out_dir/]
"""
from __future__ import annotations

import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

_BAD = re.compile(r'[\\/:*?"<>|#^\[\]]')
_LINK = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]*)?\]\]")
VAULT_ROOT = "Proto Vault"


def _san(s: str) -> str:
    s = _BAD.sub("-", str(s))
    return re.sub(r"\s+", " ", s).strip() or "note"


def _t(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%H:%M:%S")


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def _cell(v) -> str:
    return str(v).replace("|", "∣").replace("\n", " ")


class _Names:
    def __init__(self):
        self.used: set[str] = set()
        self.by_key: dict[str, str] = {}

    def claim(self, key: str, base: str) -> str:
        name, i = _san(base), 2
        cand = name
        while cand.lower() in self.used:
            cand = f"{name} ({i})"
            i += 1
        self.used.add(cand.lower())
        self.by_key[key] = cand
        return cand

    def link(self, key: str, fallback: str = "") -> str:
        n = self.by_key.get(key)
        return f"[[{n}]]" if n else (fallback or str(key))


def vault_notes(os_) -> list[tuple[str, str]]:
    """Return (relative_path, markdown) pairs for the whole world."""
    N = _Names()
    idents = dict(os_.ids._identities)
    budgets = dict(os_.wallet.budgets)
    mandates = dict(os_.mandates._store)
    receipts = []
    for rail in os_.wallet.rails.values():
        receipts.extend(getattr(rail, "_receipts", {}).values())
    receipts.sort(key=lambda r: r.ts)
    tasks = list(os_.a2a.tasks.values())

    for i in idents.values():
        N.claim(i.did, i.name)
    for b in budgets.values():
        owner = idents.get(b.owner)
        N.claim(b.id, f"{owner.name if owner else b.owner} budget {b.id[-4:]}")
    for m in mandates.values():
        N.claim(m["id"], m["id"])
    for r in receipts:
        N.claim(f"r:{r.receipt_id}", r.receipt_id)
    for t in tasks:
        N.claim(t.id, t.id)
    N.claim("audit", "Audit Log")
    N.claim("rules", "Rules")
    N.claim("decisions", "Decisions")
    N.claim("feed", "Feed")

    notes: list[tuple[str, str]] = []

    def put(path: str, text: str):
        notes.append((path, text))

    ledger_by_ref = {e.get("ref"): e for e in os_.wallet.ledger}
    cards = {c.did: c for c in os_.registry.all()}

    # ---- identities ---------------------------------------------------------
    for i in idents.values():
        s = (f"---\ndid: {i.did}\nkind: {i.kind}\n"
             f"key_fingerprint: {i.public_key_hex[:16]}\n"
             f"created: {_iso(i.created)}\n---\n\n# {i.name}\n\n")
        card = cards.get(i.did)
        if card:
            s += f"> {card.description}\n\n"
            if card.skills:
                s += ("Skills: " + ", ".join(sk.get("id", "?")
                                             for sk in card.skills) + "\n")
            if card.cost:
                s += f"Cost: {card.cost}\n"
            s += "\n"
        owned = [b for b in budgets.values() if b.owner == i.did]
        if owned:
            s += "## Budgets owned\n" + "\n".join(
                f"- {N.link(b.id)} — ${os_.wallet.remaining(b.id):.2f}"
                f" remaining of ${b.limit_total:.2f}" for b in owned) + "\n\n"
        mine = [r for r in receipts if i.did in (r.payer, r.payee)][-10:]
        if mine:
            s += "## Recent receipts\n" + "\n".join(
                f"- {N.link('r:' + r.receipt_id)} — ${r.amount:.2f}"
                f" ({r.rail})" for r in mine) + "\n"
        put(f"Identities/{N.by_key[i.did]}.md", s)

    # ---- budgets ------------------------------------------------------------
    for b in budgets.values():
        spent = os_.wallet.spent(b.id)
        s = (f"---\nid: {b.id}\nlimit: {b.limit_total}\n"
             f"spent: {round(spent, 2)}\nremaining: "
             f"{round(b.limit_total - spent, 2)}\n---\n\n"
             f"# {N.by_key[b.id]}\n\n")
        s += f"Owner: {N.link(b.owner, b.owner)}\n"
        s += f"Parent: {N.link(b.parent) if b.parent else '— (root)'}\n"
        kids = [x for x in budgets.values() if x.parent == b.id]
        if kids:
            s += "Children: " + ", ".join(N.link(k.id) for k in kids) + "\n"
        if b.categories_deny:
            s += "Blocked categories: " + ", ".join(b.categories_deny) + "\n"
        txs = [e for e in os_.wallet.ledger if e.get("budget") == b.id]
        if txs:
            s += ("\n## Transactions (direct)\n"
                  "| time | amount | category | rail | ref |\n"
                  "|---|---|---|---|---|\n")
            for e in txs:
                s += (f"| {_t(e['ts'])} | ${e['amount']:.2f} |"
                      f" {_cell(e.get('category'))} | {_cell(e.get('rail'))} |"
                      f" {_cell(e.get('ref'))[:24]} |\n")
        put(f"Budgets/{N.by_key[b.id]}.md", s)

    # ---- mandates -----------------------------------------------------------
    for m in mandates.values():
        p = m["payload"]
        s = (f"---\nid: {m['id']}\ntype: {m['type']}\n"
             f"created: {_iso(m['created'])}\n---\n\n"
             f"# {m['type']} `{m['id']}`\n\n"
             f"Signer: {N.link(m['signer'], m['signer'])}\n\n")
        if m["type"] == "IntentMandate":
            s += (f"- Intent: {p.get('intent')}\n"
                  f"- Max amount: ${p.get('max_amount', 0):.2f}"
                  f" {p.get('currency')}\n"
                  f"- Categories: {p.get('categories')}\n")
            carts = [c for c in mandates.values()
                     if c["type"] == "CartMandate"
                     and c["payload"].get("intent_id") == m["id"]]
            if carts:
                s += ("\nCarts under this intent: "
                      + ", ".join(N.link(c["id"]) for c in carts) + "\n")
        elif m["type"] == "CartMandate":
            s += f"Fulfills {N.link(p.get('intent_id'), '?')}\n\n"
            s += "| item | qty | price | category |\n|---|---|---|---|\n"
            for it in p.get("items", []):
                s += (f"| {_cell(it.get('title', it.get('sku')))} |"
                      f" {it.get('qty', 1)} |"
                      f" ${it.get('unit_price', it.get('price', 0)):.2f} |"
                      f" {_cell(it.get('category'))} |\n")
            s += f"\nTotal: **${p.get('total', 0):.2f}** {p.get('currency')}\n"
            pays = [x for x in mandates.values()
                    if x["type"] == "PaymentMandate"
                    and x["payload"].get("cart_id") == m["id"]]
            if pays:
                s += ("Payment: "
                      + ", ".join(N.link(x["id"]) for x in pays) + "\n")
        else:
            s += (f"Pays cart {N.link(p.get('cart_id'), '?')}\n\n"
                  f"- Amount: ${p.get('amount', 0):.2f} {p.get('currency')}\n"
                  f"- Rail: {p.get('rail')}\n"
                  f"- Payee: {N.link(p.get('payee'), str(p.get('payee')))}\n")
        s += f"\nSignature: `{str(m.get('sig'))[:24]}…`\n"
        put(f"Mandates/{N.by_key[m['id']]}.md", s)

    # ---- receipts -----------------------------------------------------------
    for r in receipts:
        key = f"r:{r.receipt_id}"
        s = (f"---\nreceipt: {r.receipt_id}\nrail: {r.rail}\n"
             f"amount: {r.amount}\nstatus: {r.status}\n---\n\n"
             f"# Receipt `{r.receipt_id}`\n\n"
             f"- ${r.amount:.2f} {r.currency} via **{r.rail}**\n"
             f"- Payer: {N.link(r.payer, r.payer)}\n"
             f"- Payee: {N.link(r.payee, r.payee)}\n"
             f"- Ref: {_cell(r.ref) or '—'}\n- Time: {_iso(r.ts)}\n")
        led = ledger_by_ref.get(r.receipt_id)
        if led and led.get("budget") in budgets:
            s += f"- Charged to: {N.link(led['budget'])}\n"
        put(f"Receipts/{N.by_key[key]}.md", s)

    # ---- tasks --------------------------------------------------------------
    for t in tasks:
        s = (f"---\nid: {t.id}\nstate: {t.state}\nagent: {t.agent}\n---\n\n"
             f"# Task `{t.id}`\n\nAgent: {N.link(t.agent, t.agent)}\n\n")
        if t.history:
            s += "## History\n"
            for h in t.history:
                txt = " ".join(pt.get("text", "") for pt in h.get("parts", []))
                s += f"- **{h.get('role')}**: {_cell(txt)[:120]}\n"
            s += "\n"
        if t.artifacts:
            s += "## Artifacts\n"
            for a in t.artifacts:
                txt = " ".join(pt.get("text", str(pt))
                               for pt in a.get("parts", []))
                s += f"- {_cell(txt)[:160]}\n"
        put(f"Tasks/{N.by_key[t.id]}.md", s)

    # ---- policy -------------------------------------------------------------
    pol = "# Policy rules\n\n| layer | actions | condition | effect | note |\n|---|---|---|---|---|\n"
    for r in os_.engine.rules:
        pol += (f"| {r.layer} | `{_cell(','.join(r.actions))}` |"
                f" `{_cell(r.condition or 'always')}` | {r.effect} |"
                f" {_cell(r.description)} |\n")
    put(f"Policy/{N.by_key['rules']}.md", pol)

    dec = ("# Recent policy decisions\n\n"
           "| time | action | effect | reason |\n|---|---|---|---|\n")
    for e in os_.audit.by_action("policy.decision")[-30:]:
        p = e.get("payload", {})
        dec += (f"| {_t(e['ts'])} | {_cell(p.get('action'))} |"
                f" {_cell(p.get('effect'))} | {_cell(p.get('reason'))[:60]} |\n")
    put(f"Policy/{N.by_key['decisions']}.md", dec)

    # ---- audit --------------------------------------------------------------
    ok, bad = os_.audit.verify()
    au = (f"---\nentries: {len(os_.audit.entries)}\n"
          f"integrity: {'intact' if ok else f'BROKEN at #{bad}'}\n---\n\n"
          "# Audit Log\n\nHash-chained; each row commits to the previous"
          " hash.\n\n| # | time | actor | action | hash | prev |\n"
          "|---|---|---|---|---|---|\n")
    for e in os_.audit.entries:
        actor = N.link(e["actor"], e["actor"])
        au += (f"| {e['i']} | {_t(e['ts'])} | {actor} | {_cell(e['action'])} |"
               f" `{e['hash'][:10]}` | `{str(e['prev'])[:10]}` |\n")
    put(f"Audit/{N.by_key['audit']}.md", au)

    # ---- AG-UI feed ---------------------------------------------------------
    evs = [ev for run in os_.ui._events.values() for ev in run]
    evs.sort(key=lambda e: e["ts"])
    fd = ("# AG-UI event feed\n\n| time | run | type | data |\n"
          "|---|---|---|---|\n")
    for ev in evs[-100:]:
        fd += (f"| {_t(ev['ts'])} | {_cell(ev['runId'])[:10]} |"
               f" {_cell(ev['type'])} | {_cell(str(ev['data']))[:70]} |\n")
    put(f"Events/{N.by_key['feed']}.md", fd)

    # ---- README -------------------------------------------------------------
    n_pending = len(os_.pending_approvals())
    readme = (f"# Proto — world snapshot\n\nExported from ProtoOS.\n\n"
              f"- Ledger integrity: **{'intact ✓' if ok else f'broken at #{bad}'}**"
              f" ({len(os_.audit.entries)} entries)\n"
              f"- Identities: {len(idents)} · Budgets: {len(budgets)} ·"
              f" Mandates: {len(mandates)} · Receipts: {len(receipts)} ·"
              f" Tasks: {len(tasks)} · Pending approvals: {n_pending}\n\n"
              f"Open this folder as a vault in Obsidian and switch to graph"
              f" view — the wikilinks reproduce the constellation.\n\n"
              f"Start at [[{N.by_key['audit']}]] or [[{N.by_key['rules']}]].\n")
    put("README.md", readme)
    return notes


# --------------------------------------------------------------------------
# writers & checks
# --------------------------------------------------------------------------
def write_vault(os_, dest_dir) -> int:
    root = Path(dest_dir)
    for rel, text in vault_notes(os_):
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
    return sum(1 for _ in root.rglob("*.md"))


def write_vault_zip(os_, zip_path) -> int:
    notes = vault_notes(os_)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, text in notes:
            z.writestr(f"{VAULT_ROOT}/{rel}", text)
    return len(notes)


def unresolved_links(notes: list[tuple[str, str]]) -> list[str]:
    """Wikilink targets that have no matching note (empty list == healthy)."""
    targets = {Path(rel).stem for rel, _ in notes}
    missing = []
    for rel, text in notes:
        for m in _LINK.finditer(text):
            if m.group(1) not in targets:
                missing.append(f"{rel}: [[{m.group(1)}]]")
    return missing


def main(argv: list[str]) -> int:
    from protoos.graph import build_demo_world
    dest = argv[1] if len(argv) > 1 else "proto-vault.zip"
    os_, _ = build_demo_world()
    if dest.endswith(".zip"):
        n = write_vault_zip(os_, dest)
    else:
        n = write_vault(os_, dest)
    bad = unresolved_links(vault_notes(os_))
    print(f"vault: {n} notes -> {dest}; unresolved wikilinks: {len(bad)}")
    return 0 if not bad else 1


if __name__ == "__main__":  # pragma: no cover
    import sys
    sys.exit(main(sys.argv))
