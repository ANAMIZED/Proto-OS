"""ProtoOS: the control plane & runtime facade.

Developers write agents against this stable high-level model; the OS handles
identity, discovery, task lifecycle, policy, spending controls, human-in-the-
loop approvals, observability and multi-protocol adapters underneath.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

from . import a2a as agui  # AG-UI constants live alongside A2A
from .a2a import A2AAdapter, AGUIBus, InputRequired
from .audit import AuditLog, Tracer
from .canonical import (BudgetExceeded, Clock, PolicyDenied, ProtoError,
                        ProtoHalted, cjson, new_id)
from .commerce import Catalog
from .identity import IdentityService, default_backend
from .mcp import MCPClient, MCPMux, MCPServer, ResourceCache, ERR_PAYMENT_REQUIRED
from .policy import MandateStore, PolicyEngine
from .registry import (FederatedRegistry, LocalRegistry, SemanticIndex,
                       UnifiedAgentCard, WellKnownDirectory, rank_candidates)
from .runtime import KillSwitch, RateLimiter, SandboxedExecutor, SessionManager, TaskGraph
from .wallet import SpendingController


class PendingApproval:
    """Returned when policy requires a human in the loop; resolve via
    ProtoOS.approve()."""

    def __init__(self, approval_id: str, action: str, ctx: dict, run_id: str | None):
        self.approval_id, self.action, self.ctx, self.run_id = approval_id, action, ctx, run_id

    def __repr__(self):
        return f"<PendingApproval {self.approval_id} for {self.action}>"


class OSContext:
    """Handed to agent handlers: the capabilities an agent may use, routed
    through the OS so policy/budget/audit always apply."""

    def __init__(self, os: "ProtoOS", agent_did: str, run_id: str):
        self.os, self.agent_did, self.run_id = os, agent_did, run_id

    def emit_text(self, text: str) -> None:
        self.os.ui.emit(self.run_id, agui.TEXT_MESSAGE,
                        {"agent": self.agent_did, "text": text})

    def call_tool(self, tool: str, arguments: dict, budget_id: str | None = None):
        return self.os.call_tool(self.agent_did, tool, arguments,
                                 run_id=self.run_id, budget_id=budget_id)

    def discover(self, query: str, k: int = 5, max_cost: float | None = None):
        return self.os.discover(query, k=k, max_cost=max_cost)

    def delegate(self, to_did: str, message: str, budget_id: str | None = None):
        return self.os.delegate(self.agent_did, to_did, message,
                                budget_id=budget_id, run_id=self.run_id)

    def state(self, **delta):
        return self.os.ui.apply_state_delta(self.run_id, delta)


class ProtoOS:
    def __init__(self, clock: Clock | None = None, data_dir: str | None = None):
        self.clock = clock or Clock()
        self.data_dir = Path(data_dir) if data_dir else Path(tempfile.mkdtemp(prefix="protoos_"))
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.audit = AuditLog(self.clock)
        self.tracer = Tracer(self.clock)
        self.ids = IdentityService(default_backend(), self.clock,
                                   wellknown_root=self.data_dir / "wellknown")
        self.engine = PolicyEngine(self.audit)
        self.mandates = MandateStore(self.ids, self.audit, self.clock)
        self.wallet = SpendingController(self.engine, self.mandates, self.ids,
                                         self.audit, self.clock)
        self.local_registry = LocalRegistry()
        self.wellknown = WellKnownDirectory(self.data_dir / "wellknown")
        self.registry = FederatedRegistry([self.local_registry, self.wellknown])
        self.index = SemanticIndex()
        self.ui = AGUIBus(self.clock)
        self.a2a = A2AAdapter(self.clock, self.audit)
        self.mcp = MCPMux()
        self.cache = ResourceCache(self.engine, self.audit)
        self.rate = RateLimiter(self.clock, rate_per_sec=20.0, burst=40)
        self.killswitch = KillSwitch()
        self.sandbox = SandboxedExecutor()
        self.sessions = SessionManager(self.clock)
        self._agents: dict[str, dict] = {}
        self._approvals: dict[str, dict] = {}
        self.audit.append("proto-os", "os.booted",
                          {"crypto_backend": self.ids.backend.name,
                           "data_dir": str(self.data_dir)})

    # ---- identities & agents -------------------------------------------------
    def create_user(self, name: str):
        u = self.ids.create_identity(name, "user")
        self.audit.append(u.did, "user.created", {"name": name})
        return u

    def create_merchant(self, name: str):
        m = self.ids.create_identity(name, "merchant")
        self.audit.append(m.did, "merchant.created", {"name": name})
        return m

    def create_agent(self, name: str, description: str, skills: list[dict] | None = None,
                     handler=None, cost: dict | None = None, labels: dict | None = None,
                     publish_open_host: str | None = None) -> UnifiedAgentCard:
        ident = self.ids.create_identity(name, "agent", labels or {})
        card = UnifiedAgentCard(did=ident.did, name=name, description=description,
                                skills=skills or [], protocols=["a2a", "mcp", "ag-ui"],
                                cost=cost or {}, labels=labels or {},
                                endpoints={"a2a": f"proto://a2a/{ident.did}"})
        self.local_registry.put(card)
        if publish_open_host:
            self.wellknown.publish(card, publish_open_host)
            self.ids.register_web_alias(ident.did, publish_open_host)
        if handler is not None:
            self.a2a.register_handler(ident.did, handler)
        token = self.ids.issue_token(ident.did, "proto-os", ["agent"], ttl=3600)
        self._agents[ident.did] = {"card": card, "token": token}
        self.index.build(self.registry.all())
        self.audit.append(ident.did, "agent.created",
                          {"name": name, "open": bool(publish_open_host)})
        return card

    # ---- discovery -------------------------------------------------------------
    def discover(self, query: str, k: int = 5, max_cost: float | None = None,
                 where=None) -> list[UnifiedAgentCard]:
        hits = self.index.search(query, k=max(k, 5), where=where)
        ranked = rank_candidates(hits, max_cost=max_cost)
        self.audit.append("proto-os", "discovery.search",
                          {"query": query, "results": [c.did for c in ranked[:k]]})
        return ranked[:k]

    # ---- approvals (human-in-the-loop as a first-class primitive) ---------------
    def _gate(self, action: str, ctx: dict, actor: str, thunk, run_id: str | None):
        decision = self.engine.evaluate(action, ctx, actor=actor)
        if decision.effect == "deny":
            self.ui.emit(run_id or "system", agui.ERROR,
                         {"action": action, "reason": decision.reason})
            raise PolicyDenied(action, decision.reason,
                               decision.matched[0] if decision.matched else None)
        if decision.effect == "require_approval":
            approval_id = new_id("appr")
            self._approvals[approval_id] = {"action": action, "ctx": ctx, "actor": actor,
                                            "thunk": thunk, "run_id": run_id,
                                            "status": "pending"}
            self.ui.emit(run_id or "system", agui.HUMAN_INPUT_REQUEST,
                         {"approvalId": approval_id, "action": action, "ctx": ctx,
                          "reason": decision.reason})
            self.audit.append(actor, "approval.requested",
                              {"approval": approval_id, "action": action})
            return PendingApproval(approval_id, action, ctx, run_id)
        return thunk()

    def approve(self, approval_id: str, approver_did: str, approved: bool):
        rec = self._approvals.get(approval_id)
        if not rec or rec["status"] != "pending":
            raise ProtoError(f"no pending approval {approval_id}")
        rec["status"] = "approved" if approved else "denied"
        self.audit.append(approver_did, "approval.resolved",
                          {"approval": approval_id, "approved": approved,
                           "action": rec["action"]})
        self.ui.emit(rec["run_id"] or "system", agui.HUMAN_INPUT_RESULT,
                     {"approvalId": approval_id, "approved": approved,
                      "approver": approver_did})
        if not approved:
            raise PolicyDenied(rec["action"], f"human approver {approver_did} declined")
        return rec["thunk"]()

    def pending_approvals(self) -> list[str]:
        return [k for k, v in self._approvals.items() if v["status"] == "pending"]

    # ---- MCP tools ----------------------------------------------------------------
    def payment_verifier(self, receipt: dict, resource: str, min_amount: float) -> bool:
        """Accept either x402 receipts or MPP session-charge receipts."""
        return (self.wallet.rails["x402"].verify_receipt(receipt, resource, min_amount)
                or self.wallet.rails["mpp"].verify_receipt(receipt, resource, min_amount))

    def make_mcp_server(self, name: str, payee_did: str = "") -> MCPServer:
        """MCP server pre-wired to this OS's x402 facilitator and verifier, so
        paid tools work with both x402 and MPP-session receipts."""
        return MCPServer(name, x402_rail=self.wallet.rails["x402"],
                         payee_did=payee_did, payment_verifier=self.payment_verifier)

    def mount_mcp(self, prefix: str, server: MCPServer) -> None:
        self.mcp.mount(prefix, server)
        self.audit.append("proto-os", "mcp.mounted",
                          {"prefix": prefix, "tools": [t["name"] for t in server.tool_defs()]})

    def call_tool(self, agent_did: str, tool: str, arguments: dict,
                  run_id: str | None = None, budget_id: str | None = None,
                  mpp_session: str | None = None):
        """Policy-gated, rate-limited, kill-switch-aware MCP call. If the tool
        demands payment (402), the OS pays via the MPP session when given one,
        otherwise via x402 under the supplied budget — both policy-checked."""
        self.killswitch.check(agent_did)
        self.rate.check(f"tool:{agent_did}")
        rid = run_id or "system"

        def do_call():
            client = MCPClient(self.mcp.handle)
            self.ui.emit(rid, agui.TOOL_CALL_START, {"tool": tool, "agent": agent_did,
                                                     "arguments": arguments})
            with self.tracer.span("tool.call", {"tool": tool, "agent": agent_did}):
                resp = client.call(tool, arguments)
                if "error" in resp and resp["error"].get("code") == ERR_PAYMENT_REQUIRED:
                    ch = resp["error"]["data"]["challenge"]
                    receipt = self._pay_for_tool(agent_did, tool, ch, budget_id, mpp_session)
                    resp = client.call(tool, arguments, receipt=receipt)
                if "error" in resp:
                    self.ui.emit(rid, agui.ERROR, {"tool": tool, "error": resp["error"]})
                    raise ProtoError(f"tool {tool}: {resp['error']['message']}")
                result = resp["result"]
            self.audit.append(agent_did, "tool.called",
                              {"tool": tool, "arguments": arguments})
            self.ui.emit(rid, agui.TOOL_CALL_END,
                         {"tool": tool, "result": result.get("structuredContent")})
            return result

        return self._gate("tool.call", {"tool": tool, "agent": agent_did}, agent_did,
                          do_call, run_id)

    def _pay_for_tool(self, agent_did: str, tool: str, challenge: dict,
                      budget_id: str | None, mpp_session: str | None) -> dict:
        amount, currency = challenge["amount"], challenge.get("currency", "USD")
        if mpp_session:
            r = self.wallet.rails["mpp"].charge(mpp_session, amount,
                                                ref=challenge.get("resource", tool))
            return r.to_json()
        if not budget_id:
            raise PolicyDenied("payment.settle", f"paid tool {tool} requires a budget or session")
        ctx = self.wallet.payment_ctx(amount, currency, "tool", "x402",
                                      agent_did, challenge.get("payee", ""), budget_id)
        decision = self.engine.evaluate("payment.settle", ctx, actor=agent_did)
        if decision.effect != "allow":
            raise PolicyDenied("payment.settle", decision.reason)
        self.wallet.check_budget(budget_id, amount, "tool")
        rail = self.wallet.rails["x402"]
        receipt = rail.settle(rail.build_payment(challenge, agent_did))
        self.wallet.record(budget_id, amount, "tool", "x402", receipt.receipt_id)
        return receipt.to_json()

    # ---- delegation (A2A) -----------------------------------------------------
    def delegate(self, from_did: str, to_did: str, message: str,
                 budget_id: str | None = None, run_id: str | None = None,
                 budget_slice: float | None = None):
        self.killswitch.check(from_did)
        self.rate.check(f"delegate:{from_did}")
        to_card = self.registry.get(to_did)
        ctx = {"from": from_did, "to": to_did,
               "to_cost": float((to_card.cost if to_card else {}).get("per_task", 0.0)),
               "has_budget": budget_id is not None}

        def do_delegate():
            sub_budget = None
            if budget_id and budget_slice:
                sub_budget = self.wallet.create_budget(to_did, budget_slice, parent=budget_id)
            meta = {"delegated_by": from_did}
            if sub_budget:
                meta["budget"] = sub_budget.id
            os_ctx = OSContext(self, to_did, run_id or new_id("run"))
            task = self.a2a.message_send(to_did, message, meta=meta, os_ctx=os_ctx)
            self.audit.append(from_did, "delegation",
                              {"to": to_did, "task": task.id,
                               "budget": meta.get("budget")})
            return task

        return self._gate("delegate", ctx, from_did, do_delegate, run_id)

    # ---- runs (AG-UI wrapped agent execution) -----------------------------------
    def run(self, agent_did: str, user_message: str, run_id: str | None = None):
        rid = run_id or new_id("run")
        self.ui.emit(rid, agui.RUN_STARTED, {"agent": agent_did, "message": user_message})
        os_ctx = OSContext(self, agent_did, rid)
        try:
            with self.tracer.span("run", {"agent": agent_did, "run": rid}):
                task = self.a2a.message_send(agent_did, user_message, os_ctx=os_ctx)
        finally:
            self.ui.emit(rid, agui.RUN_FINISHED, {"agent": agent_did})
        return rid, task

    # ---- full AP2 purchase flow ---------------------------------------------------
    def purchase(self, user_did: str, catalog: Catalog, items: list[dict],
                 intent_text: str, max_amount: float, budget_id: str,
                 rail: str = "x402", categories: list[str] | None = None,
                 agent_did: str | None = None, run_id: str | None = None):
        """Intent Mandate -> UCP checkout -> Cart Mandate -> Payment Mandate ->
        policy + budget -> settle on the chosen rail. Returns a Receipt, or a
        PendingApproval when policy requires a human."""
        rid = run_id or new_id("run")
        with self.tracer.span("purchase", {"user": user_did, "rail": rail}):
            intent = self.mandates.issue_intent(user_did, intent_text, max_amount,
                                                "USD", categories)
            cart = catalog.checkout(items)
            cart_m = self.mandates.issue_cart(catalog.merchant, intent["id"],
                                              cart["items"], cart["total"],
                                              cart["currency"], agent_did)
            pay_m = self.mandates.issue_payment(user_did, cart_m["id"], cart["total"],
                                                cart["currency"], rail, catalog.merchant)
            category = cart["items"][0]["category"] if cart["items"] else "general"
            decision, ctx = self.wallet.precheck(pay_m["id"], budget_id, category)
            self.ui.apply_state_delta(rid, {"cart_total": cart["total"],
                                            "payment_mandate": pay_m["id"]})

            def do_settle():
                receipt = self.wallet.settle(pay_m["id"], budget_id, category)
                self.ui.emit(rid, agui.TEXT_MESSAGE,
                             {"text": f"paid {receipt.amount} {receipt.currency} "
                                      f"via {receipt.rail}", "receipt": receipt.receipt_id})
                return receipt

            if decision.effect == "deny":
                self.ui.emit(rid, agui.ERROR, {"action": "payment.settle",
                                               "reason": decision.reason})
                raise PolicyDenied("payment.settle", decision.reason)
            if decision.effect == "require_approval":
                approval_id = new_id("appr")
                self._approvals[approval_id] = {"action": "payment.settle", "ctx": ctx,
                                                "actor": user_did, "thunk": do_settle,
                                                "run_id": rid, "status": "pending"}
                self.ui.emit(rid, agui.HUMAN_INPUT_REQUEST,
                             {"approvalId": approval_id, "action": "payment.settle",
                              "ctx": ctx, "reason": decision.reason})
                self.audit.append(user_did, "approval.requested",
                                  {"approval": approval_id, "action": "payment.settle"})
                return PendingApproval(approval_id, "payment.settle", ctx, rid)
            return do_settle()

    # ---- exports & self-verification ------------------------------------------
    def export(self, out_dir: str | None = None) -> dict:
        d = Path(out_dir) if out_dir else self.data_dir
        d.mkdir(parents=True, exist_ok=True)
        n_audit = self.audit.export_jsonl(d / "audit.jsonl")
        n_spans = self.tracer.export_jsonl(d / "traces.jsonl")
        return {"audit_entries": n_audit, "spans": n_spans, "dir": str(d)}

    def verify_integrity(self) -> dict:
        ok, bad = self.audit.verify()
        return {"audit_chain_ok": ok, "first_bad_index": bad,
                "audit_entries": len(self.audit.entries),
                "spans": len(self.tracer.spans),
                "crypto_backend": self.ids.backend.name,
                "pending_approvals": len(self.pending_approvals())}
