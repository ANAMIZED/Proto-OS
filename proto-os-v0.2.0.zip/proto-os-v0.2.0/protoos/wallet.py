"""Commerce & Payments plane.

  - Budget hierarchies with total limits, rolling-window limits, and
    category allow/deny controls; cumulative ledger accounting.
  - Rails: X402Rail (HTTP-402 challenge -> signed payment payload ->
    facilitator settle, simulated in-process), MPPRail (prepaid multi-call
    sessions for high-frequency use), TraditionalRail (card/ACH-shaped,
    pending -> settled).
  - SpendingController: AP2 mandate-chain verification + policy evaluation
    before any settlement; routes to the chosen rail; every step audited.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .audit import AuditLog
from .canonical import BudgetExceeded, Clock, MandateInvalid, PolicyDenied, ProtoError, cjson, new_id
from .identity import IdentityService
from .policy import Decision, MandateStore, PolicyEngine


@dataclass
class Budget:
    id: str
    owner: str
    limit_total: float
    parent: str | None = None
    window: tuple[float, float] | None = None      # (amount, seconds)
    categories_allow: list[str] | None = None
    categories_deny: list[str] = field(default_factory=list)


@dataclass
class Receipt:
    receipt_id: str
    rail: str
    amount: float
    currency: str
    payer: str
    payee: str
    ts: float
    status: str = "settled"
    ref: str = ""
    meta: dict = field(default_factory=dict)

    def to_json(self) -> dict:
        return dict(self.__dict__)


class X402Rail:
    """HTTP-402 style micro/crypto rail with an in-process facilitator."""

    name = "x402"

    def __init__(self, ids: IdentityService, audit: AuditLog, clock: Clock):
        self.ids, self.audit, self.clock = ids, audit, clock
        self._nonces: set[str] = set()
        self._receipts: dict[str, Receipt] = {}

    def challenge(self, resource: str, amount: float, currency: str, payee: str) -> dict:
        return {"scheme": "x402", "resource": resource, "amount": round(amount, 6),
                "currency": currency, "payee": payee, "nonce": new_id("nonce")}

    def build_payment(self, challenge: dict, payer_did: str) -> dict:
        body = {"challenge": challenge, "payer": payer_did, "ts": self.clock.now()}
        return {**body, "sig": self.ids.sign_as(payer_did, body)}

    def settle(self, payment: dict) -> Receipt:
        body = {k: v for k, v in payment.items() if k != "sig"}
        ch = payment["challenge"]
        if ch["nonce"] in self._nonces:
            raise ProtoError("x402: nonce replay")
        if not self.ids.verify_for(payment["payer"], payment["sig"], body):
            raise ProtoError("x402: bad payment signature")
        self._nonces.add(ch["nonce"])
        r = Receipt(new_id("rcpt"), self.name, ch["amount"], ch["currency"],
                    payment["payer"], ch["payee"], self.clock.now(),
                    ref=ch["resource"], meta={"nonce": ch["nonce"]})
        self._receipts[r.receipt_id] = r
        self.audit.append("x402-facilitator", "payment.settled", r.to_json())
        return r

    def verify_receipt(self, receipt: dict, resource: str, min_amount: float) -> bool:
        r = self._receipts.get(receipt.get("receipt_id", ""))
        return bool(r and r.ref == resource and r.amount + 1e-9 >= min_amount
                    and r.status == "settled")


class MPPRail:
    """Prepaid session rail for high-frequency tool/API use."""

    name = "mpp"

    def __init__(self, audit: AuditLog, clock: Clock):
        self.audit, self.clock = audit, clock
        self.sessions: dict[str, dict] = {}
        self._receipts: dict[str, Receipt] = {}

    def open_session(self, payer: str, payee: str, deposit: float, currency: str) -> dict:
        s = {"session_id": new_id("mppsess"), "payer": payer, "payee": payee,
             "deposit": round(deposit, 6), "balance": round(deposit, 6),
             "currency": currency, "calls": 0, "open": True}
        self.sessions[s["session_id"]] = s
        self.audit.append(payer, "payment.session_opened", dict(s))
        return s

    def charge(self, session_id: str, amount: float, ref: str = "") -> Receipt:
        s = self.sessions.get(session_id)
        if not s or not s["open"]:
            raise ProtoError("mpp: no such open session")
        if s["balance"] + 1e-9 < amount:
            raise BudgetExceeded("mpp: session balance exhausted")
        s["balance"] = round(s["balance"] - amount, 6)
        s["calls"] += 1
        r = Receipt(new_id("rcpt"), self.name, round(amount, 6), s["currency"],
                    s["payer"], s["payee"], self.clock.now(), ref=ref,
                    meta={"session": session_id, "call": s["calls"]})
        self._receipts[r.receipt_id] = r
        self.audit.append(s["payer"], "payment.session_charge", r.to_json())
        return r

    def verify_receipt(self, receipt: dict, resource: str, min_amount: float) -> bool:
        r = self._receipts.get(receipt.get("receipt_id", ""))
        return bool(r and r.ref == resource and r.amount + 1e-9 >= min_amount
                    and r.status == "settled")

    def close_session(self, session_id: str) -> float:
        s = self.sessions.get(session_id)
        if not s or not s["open"]:
            raise ProtoError("mpp: no such open session")
        s["open"] = False
        refund = s["balance"]
        self.audit.append(s["payer"], "payment.session_closed",
                          {"session": session_id, "refund": refund, "calls": s["calls"]})
        return refund


class TraditionalRail:
    name = "traditional"

    def __init__(self, audit: AuditLog, clock: Clock):
        self.audit, self.clock = audit, clock
        self._pending: dict[str, Receipt] = {}
        self._receipts: dict[str, Receipt] = {}

    def settle(self, payer: str, payee: str, amount: float, currency: str, ref: str) -> Receipt:
        r = Receipt(new_id("rcpt"), self.name, round(amount, 2), currency, payer, payee,
                    self.clock.now(), status="pending", ref=ref)
        self._pending[r.receipt_id] = r
        self._receipts[r.receipt_id] = r
        self.audit.append(payer, "payment.initiated", r.to_json())
        # Simulated clearing: immediately settled in-process.
        r.status = "settled"
        self.audit.append("traditional-rail", "payment.settled", r.to_json())
        return r


class SpendingController:
    """Unified spending controller: AP2 authorization, budget enforcement,
    policy evaluation, then routing to x402 / MPP / traditional rails."""

    def __init__(self, engine: PolicyEngine, mandates: MandateStore,
                 ids: IdentityService, audit: AuditLog, clock: Clock):
        self.engine, self.mandates = engine, mandates
        self.ids, self.audit, self.clock = ids, audit, clock
        self.budgets: dict[str, Budget] = {}
        self.ledger: list[dict] = []
        self.rails = {
            "x402": X402Rail(ids, audit, clock),
            "mpp": MPPRail(audit, clock),
            "traditional": TraditionalRail(audit, clock),
        }

    # -- budgets ----------------------------------------------------------------
    def create_budget(self, owner: str, limit_total: float, parent: str | None = None,
                      window: tuple[float, float] | None = None,
                      categories_allow: list[str] | None = None,
                      categories_deny: list[str] | None = None) -> Budget:
        b = Budget(new_id("bud"), owner, float(limit_total), parent, window,
                   categories_allow, list(categories_deny or []))
        if parent and parent not in self.budgets:
            raise ProtoError(f"unknown parent budget {parent}")
        self.budgets[b.id] = b
        self.audit.append(owner, "wallet.budget_created",
                          {"budget": b.id, "limit": b.limit_total, "parent": parent,
                           "window": window, "categories_allow": categories_allow,
                           "categories_deny": categories_deny or []})
        return b

    def _chain(self, budget_id: str) -> list[Budget]:
        chain, cur = [], self.budgets.get(budget_id)
        while cur:
            chain.append(cur)
            cur = self.budgets.get(cur.parent) if cur.parent else None
        if not chain:
            raise ProtoError(f"unknown budget {budget_id}")
        return chain

    def _ancestors(self, budget_id: str) -> set[str]:
        return {b.id for b in self._chain(budget_id)}

    def spent(self, budget_id: str, since: float | None = None) -> float:
        """Spend recorded on a budget counts toward that budget and all of its
        ancestors (roll-up), never toward children or siblings."""
        total = 0.0
        for e in self.ledger:
            if since is not None and e["ts"] < since:
                continue
            if budget_id in self._ancestors(e["budget"]):
                total += e["amount"]
        return round(total, 6)

    def remaining(self, budget_id: str) -> float:
        return round(min(b.limit_total - self.spent(b.id) for b in self._chain(budget_id)), 6)

    def check_budget(self, budget_id: str, amount: float, category: str) -> None:
        now = self.clock.now()
        for b in self._chain(budget_id):
            if b.categories_allow is not None and category not in b.categories_allow:
                raise BudgetExceeded(f"budget {b.id}: category '{category}' not allowed")
            if category in b.categories_deny:
                raise BudgetExceeded(f"budget {b.id}: category '{category}' denied")
            if self.spent(b.id) + amount > b.limit_total + 1e-9:
                raise BudgetExceeded(f"budget {b.id}: cumulative limit {b.limit_total} exceeded")
            if b.window:
                wamount, wsecs = b.window
                if self.spent(b.id, since=now - wsecs) + amount > wamount + 1e-9:
                    raise BudgetExceeded(f"budget {b.id}: window limit {wamount}/{wsecs}s exceeded")

    def record(self, budget_id: str, amount: float, category: str, rail: str, ref: str) -> None:
        entry = {"ts": self.clock.now(), "budget": budget_id, "amount": round(amount, 6),
                 "category": category, "rail": rail, "ref": ref}
        self.ledger.append(entry)
        self.audit.append("spending-controller", "wallet.ledger", entry)

    # -- payment context for policy ----------------------------------------------
    def payment_ctx(self, amount: float, currency: str, category: str, rail: str,
                    payer: str, payee: str, budget_id: str | None) -> dict:
        now = self.clock.now()
        ctx = {"amount": round(float(amount), 6), "currency": currency, "category": category,
               "rail": rail, "payer": payer, "payee": payee,
               "hour": int((now // 3600) % 24)}
        if budget_id:
            ctx["budget_remaining"] = self.remaining(budget_id)
            ctx["spent_24h"] = self.spent(budget_id, since=now - 86400)
        else:
            ctx["budget_remaining"] = 0.0
            ctx["spent_24h"] = 0.0
        return ctx

    def precheck(self, payment_id: str, budget_id: str, category: str) -> tuple[Decision, dict]:
        ok, why = self.mandates.verify_chain(payment_id)
        if not ok:
            raise MandateInvalid(f"mandate chain invalid: {why}")
        pay = self.mandates.get(payment_id)["payload"]
        self.check_budget(budget_id, pay["amount"], category)
        ctx = self.payment_ctx(pay["amount"], pay["currency"], category, pay["rail"],
                               pay["payer"], pay["payee"], budget_id)
        decision = self.engine.evaluate("payment.settle", ctx, actor=pay["payer"])
        return decision, ctx

    def settle(self, payment_id: str, budget_id: str, category: str) -> Receipt:
        """Assumes precheck returned allow (or an approval was granted)."""
        pay = self.mandates.get(payment_id)["payload"]
        rail = self.rails.get(pay["rail"])
        if rail is None:
            raise ProtoError(f"unknown rail {pay['rail']}")
        if isinstance(rail, X402Rail):
            ch = rail.challenge(f"mandate:{payment_id}", pay["amount"], pay["currency"],
                                pay["payee"])
            receipt = rail.settle(rail.build_payment(ch, pay["payer"]))
        elif isinstance(rail, TraditionalRail):
            receipt = rail.settle(pay["payer"], pay["payee"], pay["amount"], pay["currency"],
                                  ref=f"mandate:{payment_id}")
        else:
            raise ProtoError("mpp settles via sessions; use open_session/charge")
        self.record(budget_id, pay["amount"], category, pay["rail"], receipt.receipt_id)
        return receipt
