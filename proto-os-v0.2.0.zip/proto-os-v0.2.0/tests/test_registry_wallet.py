import tempfile
import unittest
from pathlib import Path

from protoos import (AuditLog, BudgetExceeded, FixedClock, FederatedRegistry,
                     IdentityService, LocalRegistry, MandateStore, PolicyEngine,
                     ProtoError, SemanticIndex, SpendingController,
                     UnifiedAgentCard, WellKnownDirectory, default_backend,
                     rank_candidates)


def card(did, name, desc, cost=0.0, tags=None):
    return UnifiedAgentCard(did=did, name=name, description=desc,
                            skills=[{"id": "s1", "name": name, "description": desc,
                                     "tags": tags or []}],
                            cost={"per_task": cost})


class TestRegistry(unittest.TestCase):
    def test_D1_card_superset_roundtrip(self):
        c = UnifiedAgentCard(did="did:proto:x", name="poly", description="does things",
                             skills=[{"id": "t", "name": "translate"}],
                             tools=["util.echo"], products=[{"title": "ebook",
                                                             "category": "digital"}],
                             endpoints={"a2a": "proto://a2a/x", "mcp": "proto://mcp/x"},
                             protocols=["a2a", "mcp"], cost={"per_task": 0.5},
                             labels={"tier": "gold"})
        j = c.to_json()
        self.assertEqual(j["@context"], "https://protoos.dev/context/v1")
        c2 = UnifiedAgentCard.from_json(j)
        self.assertEqual(c2.to_json(), j)
        self.assertIn("translate", c2.text())

    def test_D2_local_registry_crd_shape(self):
        reg = LocalRegistry()
        rec1 = reg.put(card("did:proto:a", "a", "alpha"))
        rec2 = reg.put(card("did:proto:b", "b", "beta"))
        self.assertEqual(rec1["kind"], "AgentCard")
        self.assertEqual(rec1["apiVersion"], "proto.dev/v1")
        self.assertEqual(int(rec2["metadata"]["resourceVersion"]),
                         int(rec1["metadata"]["resourceVersion"]) + 1)
        self.assertEqual(reg.get("did:proto:a").name, "a")
        self.assertTrue(reg.remove("did:proto:a"))
        self.assertIsNone(reg.get("did:proto:a"))

    def test_D2_wellknown_publish_resolve(self):
        root = Path(tempfile.mkdtemp())
        wk = WellKnownDirectory(root)
        f = wk.publish(card("did:proto:open1", "open", "an open agent"), "open.example.com")
        self.assertTrue(str(f).endswith("open.example.com/.well-known/agent.json"))
        got = wk.resolve("open.example.com")
        self.assertEqual(got.did, "did:proto:open1")
        self.assertIsNone(wk.resolve("missing.example.com"))
        self.assertEqual(len(wk.all()), 1)

    def test_D2_federated_union_dedupe(self):
        local = LocalRegistry()
        local.put(card("did:proto:a", "a", "alpha"))
        local.put(card("did:proto:shared", "shared", "in both"))
        wk = WellKnownDirectory(Path(tempfile.mkdtemp()))
        wk.publish(card("did:proto:shared", "shared", "in both"), "s.example.com")
        wk.publish(card("did:proto:c", "c", "gamma"), "c.example.com")
        fed = FederatedRegistry([local, wk])
        dids = sorted(c.did for c in fed.all())
        self.assertEqual(dids, ["did:proto:a", "did:proto:c", "did:proto:shared"])
        self.assertEqual(fed.get("did:proto:c").name, "c")

    def test_D3_semantic_search_relevance_and_filter(self):
        cards = [
            card("did:proto:tr", "polyglot", "translate text between english and french",
                 tags=["translation", "language"]),
            card("did:proto:wx", "weatherbot", "current weather forecasts and rain radar"),
            card("did:proto:fin", "ledgerbot", "bookkeeping invoices and accounting"),
        ]
        idx = SemanticIndex()
        idx.build(cards)
        hits = idx.search("translate english to french")
        self.assertEqual(hits[0][0].did, "did:proto:tr")
        hits2 = idx.search("translate english to french",
                           where=lambda c: c.did != "did:proto:tr")
        self.assertTrue(all(c.did != "did:proto:tr" for c, _ in hits2))

    def test_R2_cost_aware_ranking(self):
        a = card("did:proto:cheap", "cheap", "translate text", cost=0.10)
        b = card("did:proto:pricey", "pricey", "translate text", cost=5.00)
        ranked = rank_candidates([(a, 0.9), (b, 0.9)], max_cost=1.0)
        self.assertEqual([c.did for c in ranked], ["did:proto:cheap"])
        ranked2 = rank_candidates([(a, 0.9), (b, 0.9)])
        self.assertEqual(ranked2[0].did, "did:proto:cheap")


class TestWallet(unittest.TestCase):
    def setUp(self):
        self.clock = FixedClock()
        self.audit = AuditLog(self.clock)
        self.ids = IdentityService(default_backend(), self.clock)
        self.engine = PolicyEngine(self.audit)
        self.mandates = MandateStore(self.ids, self.audit, self.clock)
        self.ctl = SpendingController(self.engine, self.mandates, self.ids,
                                      self.audit, self.clock)
        self.user = self.ids.create_identity("user", "user")
        self.shop = self.ids.create_identity("shop", "merchant")

    def _payment(self, total, rail="x402", category="digital", max_amount=1000):
        intent = self.mandates.issue_intent(self.user.did, "buy", max_amount, "USD",
                                            [category])
        cart = self.mandates.issue_cart(self.shop.did, intent["id"],
                                        [{"sku": "x", "qty": 1, "category": category}],
                                        total, "USD")
        return self.mandates.issue_payment(self.user.did, cart["id"], total, "USD",
                                           rail, self.shop.did)

    def test_M3_budget_cumulative_limit(self):
        b = self.ctl.create_budget(self.user.did, 100.0)
        self.ctl.check_budget(b.id, 60, "digital")
        self.ctl.record(b.id, 60, "digital", "x402", "r1")
        with self.assertRaises(BudgetExceeded):
            self.ctl.check_budget(b.id, 50, "digital")
        self.assertAlmostEqual(self.ctl.remaining(b.id), 40.0)

    def test_M3_budget_window_limit_resets(self):
        b = self.ctl.create_budget(self.user.did, 1000.0, window=(50.0, 3600))
        self.ctl.record(b.id, 45, "digital", "x402", "r1")
        with self.assertRaises(BudgetExceeded):
            self.ctl.check_budget(b.id, 10, "digital")
        self.clock.advance(3601)
        self.ctl.check_budget(b.id, 10, "digital")  # window rolled over

    def test_M3_budget_category_controls(self):
        allow = self.ctl.create_budget(self.user.did, 100, categories_allow=["digital"])
        self.ctl.check_budget(allow.id, 5, "digital")
        with self.assertRaises(BudgetExceeded):
            self.ctl.check_budget(allow.id, 5, "gambling")
        deny = self.ctl.create_budget(self.user.did, 100, categories_deny=["gambling"])
        with self.assertRaises(BudgetExceeded):
            self.ctl.check_budget(deny.id, 5, "gambling")

    def test_M3_budget_hierarchy_child_capped_by_parent(self):
        parent = self.ctl.create_budget("org", 100.0)
        child = self.ctl.create_budget(self.user.did, 80.0, parent=parent.id)
        self.ctl.record(parent.id, 70, "digital", "x402", "r-org")
        with self.assertRaises(BudgetExceeded):
            self.ctl.check_budget(child.id, 40, "digital")  # parent only has 30 left
        self.ctl.check_budget(child.id, 25, "digital")
        with self.assertRaises(ProtoError):
            self.ctl.create_budget("x", 10, parent="bud_missing")

    def test_M1_precheck_and_settle_x402(self):
        self.engine.add_rule("user", "allow", ["payment.settle"], "amount <= 100")
        b = self.ctl.create_budget(self.user.did, 500.0)
        pay = self._payment(20.0)
        decision, ctx = self.ctl.precheck(pay["id"], b.id, "digital")
        self.assertEqual(decision.effect, "allow")
        self.assertIn("spent_24h", ctx)
        r = self.ctl.settle(pay["id"], b.id, "digital")
        self.assertEqual(r.rail, "x402")
        self.assertEqual(r.status, "settled")
        self.assertAlmostEqual(self.ctl.spent(b.id), 20.0)
        self.assertTrue(any(e["action"] == "payment.settled" for e in self.audit.entries))
        ok, _ = self.audit.verify()
        self.assertTrue(ok)

    def test_M1_settle_traditional_rail(self):
        self.engine.add_rule("user", "allow", ["payment.settle"])
        b = self.ctl.create_budget(self.user.did, 500.0)
        pay = self._payment(75.0, rail="traditional")
        decision, _ = self.ctl.precheck(pay["id"], b.id, "digital")
        self.assertEqual(decision.effect, "allow")
        r = self.ctl.settle(pay["id"], b.id, "digital")
        self.assertEqual((r.rail, r.status), ("traditional", "settled"))
        self.assertTrue(any(e["action"] == "payment.initiated" for e in self.audit.entries))

    def test_M4_mpp_session_lifecycle(self):
        mpp = self.ctl.rails["mpp"]
        s = mpp.open_session(self.user.did, self.shop.did, 1.00, "USD")
        for _ in range(4):
            mpp.charge(s["session_id"], 0.20, ref="api:call")
        self.assertAlmostEqual(mpp.sessions[s["session_id"]]["balance"], 0.20)
        with self.assertRaises(BudgetExceeded):
            mpp.charge(s["session_id"], 0.25)
        refund = mpp.close_session(s["session_id"])
        self.assertAlmostEqual(refund, 0.20)
        with self.assertRaises(ProtoError):
            mpp.charge(s["session_id"], 0.10)

    def test_x402_nonce_replay_rejected(self):
        x = self.ctl.rails["x402"]
        ch = x.challenge("res:1", 0.5, "USD", self.shop.did)
        payment = x.build_payment(ch, self.user.did)
        x.settle(payment)
        with self.assertRaises(ProtoError):
            x.settle(payment)

    def test_x402_bad_signature_rejected(self):
        x = self.ctl.rails["x402"]
        ch = x.challenge("res:2", 0.5, "USD", self.shop.did)
        payment = x.build_payment(ch, self.user.did)
        payment["sig"] = "00" * 64
        with self.assertRaises(ProtoError):
            x.settle(payment)

    def test_M1_payment_ctx_fields(self):
        b = self.ctl.create_budget(self.user.did, 100.0)
        self.ctl.record(b.id, 10, "digital", "x402", "r1")
        ctx = self.ctl.payment_ctx(5, "USD", "digital", "x402", self.user.did,
                                   self.shop.did, b.id)
        self.assertEqual(ctx["spent_24h"], 10.0)
        self.assertEqual(ctx["budget_remaining"], 90.0)
        self.assertIn("hour", ctx)


if __name__ == "__main__":
    unittest.main()
