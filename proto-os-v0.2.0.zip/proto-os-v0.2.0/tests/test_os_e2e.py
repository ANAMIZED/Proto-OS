import tempfile
import unittest
from pathlib import Path

from protoos import (BudgetExceeded, Catalog, FixedClock, MandateInvalid,
                     PendingApproval, PolicyDenied, ProtoHalted, ProtoOS,
                     RateLimited)
from protoos.a2a import (HUMAN_INPUT_REQUEST, HUMAN_INPUT_RESULT, RUN_FINISHED,
                         RUN_STARTED, TEXT_MESSAGE, TOOL_CALL_END, TOOL_CALL_START)


class E2EBase(unittest.TestCase):
    def setUp(self):
        self.clock = FixedClock()
        self.os = ProtoOS(self.clock, data_dir=tempfile.mkdtemp(prefix="protoos_test_"))
        # Four-layer policy: platform hard cap, org approval band, user allowances.
        self.os.engine.add_rule("platform", "deny", ["payment.settle"], "amount > 1000",
                                description="platform hard cap")
        self.os.engine.add_rule("org", "require_approval", ["payment.settle"],
                                "50 < amount <= 200",
                                description="human approves large spend")
        self.os.engine.add_rule("user", "allow", ["payment.settle"], "amount <= 200")
        self.os.engine.add_rule("user", "allow", ["delegate"])
        self.os.engine.add_rule("org", "deny", ["tool.call"], "tool == 'util.rm_rf'",
                                description="dangerous tool blocked")
        self.user = self.os.create_user("casey")
        self.merchant = self.os.create_merchant("ebook-shop")
        self.catalog = Catalog(self.merchant.did, "ebook-shop")
        self.catalog.add("bk1", "Distributed Systems 101", 10.00, "USD", "digital")
        self.catalog.add("bk2", "Agents in Production", 60.00, "USD", "digital")
        self.budget = self.os.wallet.create_budget(self.user.did, 500.0,
                                                   window=(300.0, 86400))
        srv = self.os.make_mcp_server("util", payee_did=self.merchant.did)
        srv.add_tool("echo", "echo", {"type": "object",
                                      "properties": {"t": {"type": "string"}}},
                     lambda t="": {"echo": t})
        srv.add_tool("rm_rf", "danger", {"type": "object", "properties": {}},
                     lambda: "boom")
        srv.add_tool("premium", "paid lookup",
                     {"type": "object", "properties": {"q": {"type": "string"}}},
                     lambda q="": {"answer": f"about {q}"}, price=0.10)
        self.os.mount_mcp("util", srv)

    def agent(self, name="worker", handler=None, cost=None):
        return self.os.create_agent(name, f"{name} agent", handler=handler, cost=cost)


class TestPurchaseFlows(E2EBase):
    def test_M1_E2E_purchase_small_settles_x402(self):
        receipt = self.os.purchase(self.user.did, self.catalog,
                                   [{"sku": "bk1", "qty": 2}],
                                   "buy two intro ebooks", max_amount=100,
                                   budget_id=self.budget.id,
                                   categories=["digital"], run_id="run-buy")
        self.assertEqual(receipt.status, "settled")
        self.assertEqual(receipt.rail, "x402")
        self.assertAlmostEqual(receipt.amount, 20.0)
        self.assertAlmostEqual(self.os.wallet.spent(self.budget.id), 20.0)
        types = [e["type"] for e in self.os.ui.events("run-buy")]
        self.assertIn(TEXT_MESSAGE, types)
        chain_entries = self.os.audit.by_action("mandate.issued")
        self.assertEqual(len(chain_entries), 3)  # intent, cart, payment
        ok, _ = self.os.audit.verify()
        self.assertTrue(ok)

    def test_M1_E2E_large_purchase_requires_human_then_settles(self):
        pending = self.os.purchase(self.user.did, self.catalog,
                                   [{"sku": "bk2", "qty": 2}],
                                   "buy the pricey book twice", max_amount=200,
                                   budget_id=self.budget.id,
                                   categories=["digital"], run_id="run-big")
        self.assertIsInstance(pending, PendingApproval)
        self.assertIn(pending.approval_id, self.os.pending_approvals())
        evs = self.os.ui.events("run-big")
        self.assertIn(HUMAN_INPUT_REQUEST, [e["type"] for e in evs])
        receipt = self.os.approve(pending.approval_id, self.user.did, True)
        self.assertEqual(receipt.status, "settled")
        self.assertAlmostEqual(self.os.wallet.spent(self.budget.id), 120.0)
        self.assertIn(HUMAN_INPUT_RESULT,
                      [e["type"] for e in self.os.ui.events("run-big")])
        self.assertEqual(self.os.pending_approvals(), [])

    def test_U2_E2E_human_declines_no_money_moves(self):
        pending = self.os.purchase(self.user.did, self.catalog,
                                   [{"sku": "bk2", "qty": 1}],
                                   "buy pricey book", max_amount=200,
                                   budget_id=self.budget.id, categories=["digital"])
        with self.assertRaises(PolicyDenied):
            self.os.approve(pending.approval_id, self.user.did, False)
        self.assertAlmostEqual(self.os.wallet.spent(self.budget.id), 0.0)
        resolved = self.os.audit.by_action("approval.resolved")
        self.assertFalse(resolved[-1]["payload"]["approved"])

    def test_G2_E2E_policy_denies_over_allowance(self):
        with self.assertRaises(PolicyDenied):
            self.os.purchase(self.user.did, self.catalog,
                             [{"sku": "bk2", "qty": 4}],  # 240 > user allow cap 200
                             "big order", max_amount=500,
                             budget_id=self.budget.id, categories=["digital"])
        self.assertAlmostEqual(self.os.wallet.spent(self.budget.id), 0.0)

    def test_I3_E2E_mandate_category_blocks_purchase(self):
        with self.assertRaises(MandateInvalid):
            self.os.purchase(self.user.did, self.catalog,
                             [{"sku": "bk1", "qty": 1}],
                             "groceries only please", max_amount=100,
                             budget_id=self.budget.id, categories=["groceries"])

    def test_M3_E2E_window_budget_blocks_then_recovers(self):
        def buy_120():
            r = self.os.purchase(self.user.did, self.catalog,
                                 [{"sku": "bk2", "qty": 2}], "restock",
                                 max_amount=200, budget_id=self.budget.id,
                                 categories=["digital"])
            if isinstance(r, PendingApproval):
                r = self.os.approve(r.approval_id, self.user.did, True)
            return r

        buy_120()
        buy_120()  # 240 spent inside the 300/day window
        with self.assertRaises(BudgetExceeded):
            buy_120()  # would be 360 within the window
        self.clock.advance(86_401)
        receipt = buy_120()  # window rolled over
        self.assertEqual(receipt.status, "settled")

    def test_M1_E2E_traditional_rail(self):
        receipt = self.os.purchase(self.user.did, self.catalog,
                                   [{"sku": "bk1", "qty": 1}],
                                   "one book via card", max_amount=50,
                                   budget_id=self.budget.id, rail="traditional",
                                   categories=["digital"])
        self.assertEqual((receipt.rail, receipt.status), ("traditional", "settled"))


class TestToolsAndPayments(E2EBase):
    def test_T1_E2E_free_tool_call_events_and_audit(self):
        a = self.agent()
        result = self.os.call_tool(a.did, "util.echo", {"t": "hi"}, run_id="r1")
        self.assertEqual(result["structuredContent"], {"echo": "hi"})
        types = [e["type"] for e in self.os.ui.events("r1")]
        self.assertEqual(types[:2], [TOOL_CALL_START, TOOL_CALL_END])
        self.assertTrue(any(e["action"] == "tool.called"
                            for e in self.os.audit.entries))

    def test_G2_E2E_tool_call_policy_deny(self):
        a = self.agent()
        with self.assertRaises(PolicyDenied):
            self.os.call_tool(a.did, "util.rm_rf", {})

    def test_M1_E2E_paid_tool_autopays_x402_under_budget(self):
        a = self.agent()
        out = self.os.call_tool(a.did, "util.premium", {"q": "mcp"},
                                budget_id=self.budget.id)
        self.assertEqual(out["structuredContent"], {"answer": "about mcp"})
        self.assertAlmostEqual(self.os.wallet.spent(self.budget.id), 0.10)
        ledger_cats = {e["category"] for e in self.os.wallet.ledger}
        self.assertIn("tool", ledger_cats)

    def test_M4_E2E_paid_tool_via_mpp_session(self):
        a = self.agent()
        mpp = self.os.wallet.rails["mpp"]
        s = mpp.open_session(a.did, self.merchant.did, 0.50, "USD")
        for _ in range(3):
            out = self.os.call_tool(a.did, "util.premium", {"q": "x"},
                                    mpp_session=s["session_id"])
            self.assertIn("answer", out["structuredContent"])
        self.assertAlmostEqual(mpp.sessions[s["session_id"]]["balance"], 0.20)
        refund = mpp.close_session(s["session_id"])
        self.assertAlmostEqual(refund, 0.20)

    def test_M1_E2E_paid_tool_without_budget_denied(self):
        a = self.agent()
        with self.assertRaises(PolicyDenied):
            self.os.call_tool(a.did, "util.premium", {"q": "no budget"})

    def test_M3_E2E_paid_tool_budget_exhaustion(self):
        a = self.agent()
        tiny = self.os.wallet.create_budget(a.did, 0.15)
        self.os.call_tool(a.did, "util.premium", {"q": "1"}, budget_id=tiny.id)
        with self.assertRaises(BudgetExceeded):
            self.os.call_tool(a.did, "util.premium", {"q": "2"}, budget_id=tiny.id)


class TestOrchestration(E2EBase):
    def test_D3_R2_discover_then_select_by_cost(self):
        self.agent("translator-cheap", cost={"per_task": 0.10})
        self.agent("translator-lux", cost={"per_task": 9.00})
        self.os.create_agent("translator-mid", "translate text english french",
                             cost={"per_task": 1.00})
        hits = self.os.discover("translate english french", k=3, max_cost=2.0)
        self.assertTrue(hits)
        self.assertTrue(all(c.cost.get("per_task", 0) <= 2.0 for c in hits))
        self.assertTrue(any(e["action"] == "discovery.search"
                            for e in self.os.audit.entries))

    def test_R3_E2E_delegate_with_budget_slice(self):
        def worker(task, msg, ctx):
            out = ctx.call_tool("util.premium", {"q": msg},
                                budget_id=task.meta["budget"])
            ctx.state(progress="done")
            return out["structuredContent"]["answer"]

        w = self.agent("researcher", handler=worker)
        boss = self.agent("supervisor")
        task = self.os.delegate(boss.did, w.did, "quantum", budget_id=self.budget.id,
                                budget_slice=1.00)
        self.assertEqual(task.state, "completed")
        self.assertEqual(task.artifacts[0]["parts"][0]["text"], "about quantum")
        self.assertAlmostEqual(self.os.wallet.spent(self.budget.id), 0.10)
        self.assertTrue(any(e["action"] == "delegation"
                            for e in self.os.audit.entries))
        sub = task.meta["budget"]
        self.assertAlmostEqual(self.os.wallet.remaining(sub), 0.90)

    def test_R3_E2E_delegation_denied_without_rule(self):
        fresh = ProtoOS(self.clock, data_dir=tempfile.mkdtemp())
        a = fresh.create_agent("a", "a", handler=lambda t, m, c: "x")
        b = fresh.create_agent("b", "b", handler=lambda t, m, c: "y")
        with self.assertRaises(PolicyDenied):
            fresh.delegate(a.did, b.did, "hello")

    def test_U1_E2E_run_wraps_agui_stream(self):
        def chatty(task, msg, ctx):
            ctx.emit_text(f"thinking about {msg}")
            return "done"
        a = self.agent("chatty", handler=chatty)
        rid, task = self.os.run(a.did, "the weather")
        types = [e["type"] for e in self.os.ui.events(rid)]
        self.assertEqual(types[0], RUN_STARTED)
        self.assertEqual(types[-1], RUN_FINISHED)
        self.assertIn(TEXT_MESSAGE, types)
        self.assertEqual(task.state, "completed")

    def test_G4_E2E_killswitch_halts_tools_and_delegation(self):
        a = self.agent("worker2", handler=lambda t, m, c: "x")
        self.os.killswitch.engage()
        with self.assertRaises(ProtoHalted):
            self.os.call_tool(a.did, "util.echo", {"t": "x"})
        with self.assertRaises(ProtoHalted):
            self.os.delegate(a.did, a.did, "loop")
        self.os.killswitch.release()
        self.os.killswitch.engage(a.did)
        with self.assertRaises(ProtoHalted):
            self.os.call_tool(a.did, "util.echo", {"t": "x"})

    def test_G4_E2E_rate_limit_enforced(self):
        from protoos.runtime import RateLimiter
        self.os.rate = RateLimiter(self.clock, rate_per_sec=0.0, burst=2)
        a = self.agent("spammy")
        self.os.call_tool(a.did, "util.echo", {"t": "1"})
        self.os.call_tool(a.did, "util.echo", {"t": "2"})
        with self.assertRaises(RateLimited):
            self.os.call_tool(a.did, "util.echo", {"t": "3"})

    def test_C5_export_and_verify_integrity(self):
        a = self.agent("worker3")
        self.os.call_tool(a.did, "util.echo", {"t": "x"}, run_id="r")
        out = self.os.export()
        self.assertTrue(Path(out["dir"], "audit.jsonl").exists())
        self.assertTrue(Path(out["dir"], "traces.jsonl").exists())
        summary = self.os.verify_integrity()
        self.assertTrue(summary["audit_chain_ok"])
        self.assertGreater(summary["audit_entries"], 5)
        self.assertGreater(summary["spans"], 0)
        self.assertIn(summary["crypto_backend"], ("ed25519", "hmac-sha256"))


if __name__ == "__main__":
    unittest.main()
