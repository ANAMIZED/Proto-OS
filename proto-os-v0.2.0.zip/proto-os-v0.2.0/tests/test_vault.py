"""Obsidian vault export: notes, wikilinks, audit fidelity, zip, hygiene."""
import re
import tempfile
import unittest
import zipfile
from pathlib import Path

from protoos.graph import build_demo_world
from protoos.vault import (unresolved_links, vault_notes, write_vault,
                           write_vault_zip, VAULT_ROOT)


class VaultTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.os_, cls.refs = build_demo_world()
        cls.notes = vault_notes(cls.os_)
        cls.by_path = dict(cls.notes)

    def test_note_population(self):
        paths = list(self.by_path)
        self.assertGreaterEqual(len(paths), 30)
        for prefix in ("Identities/", "Budgets/", "Mandates/", "Receipts/",
                       "Tasks/", "Policy/", "Audit/", "Events/"):
            self.assertTrue(any(p.startswith(prefix) for p in paths), prefix)
        self.assertIn("README.md", paths)

    def test_wikilinks_all_resolve(self):
        self.assertEqual(unresolved_links(self.notes), [])

    def test_ana_note_links_and_frontmatter(self):
        path = next(p for p in self.by_path if "Identities/Ana" in p)
        text = self.by_path[path]
        self.assertTrue(text.startswith("---\ndid: did:"))
        self.assertIn("[[", text)
        self.assertIn("Budgets owned", text)

    def test_cart_note_links_intent_and_payment(self):
        cart = next(t for p, t in self.notes
                    if p.startswith("Mandates/cartmnd"))
        self.assertIn("[[intentmnd", cart)
        self.assertIn("[[paymentmnd", cart)
        self.assertIn("Quiet headphones", "".join(t for _, t in self.notes))

    def test_audit_note_matches_chain(self):
        audit = self.by_path["Audit/Audit Log.md"]
        rows = re.findall(r"^\| \d+ \|", audit, flags=re.M)
        self.assertEqual(len(rows), len(self.os_.audit.entries))
        self.assertIn("integrity: intact", audit)

    def test_receipts_link_budgets(self):
        joined = "".join(t for p, t in self.notes if p.startswith("Receipts/"))
        self.assertIn("Charged to: [[", joined)

    def test_no_private_key_material(self):
        blob = "".join(t for _, t in self.notes)
        backend = self.os_.ids.backend
        # Whatever the backend stores privately must never reach the vault.
        for priv in getattr(backend, "_private", {}).values():
            self.assertNotIn(str(priv), blob)
        for keys in getattr(backend, "_keys", {}).values():
            self.assertNotIn(str(keys), blob)

    def test_zip_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            zp = Path(td) / "vault.zip"
            n = write_vault_zip(self.os_, zp)
            z = zipfile.ZipFile(zp)
            self.assertIsNone(z.testzip())
            self.assertEqual(len(z.namelist()), n)
            readme = z.read(f"{VAULT_ROOT}/README.md").decode()
            self.assertIn("world snapshot", readme)
            self.assertIn("intact", readme)

    def test_directory_writer(self):
        with tempfile.TemporaryDirectory() as td:
            n = write_vault(self.os_, td)
            self.assertEqual(n, len(self.notes))
            self.assertTrue((Path(td) / "README.md").exists())

    def test_pending_approval_counted(self):
        readme = self.by_path["README.md"]
        self.assertIn("Pending approvals: 1", readme)


if __name__ == "__main__":
    unittest.main()
