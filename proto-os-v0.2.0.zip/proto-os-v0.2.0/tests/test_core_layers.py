import unittest

from protoos import (AuditLog, EnterpriseIdPStub, FixedClock, IdentityService,
                     MandateStore, PolicyEngine, ProtoError, Tracer,
                     default_backend, safe_eval)


def mk_ids(clock=None):
    return IdentityService(default_backend(), clock or FixedClock())


class TestIdentity(unittest.TestCase):
    def test_I4_identity_creation_and_signature_roundtrip(self):
        ids = mk_ids()
        a = ids.create_identity("alice", "user")
        self.assertTrue(a.did.startswith("did:proto:"))
        sig = ids.sign_as(a.did, {"hello": "world"})
        self.assertTrue(ids.verify_for(a.did, sig, {"hello": "world"}))

    def test_I4_signature_rejects_tamper(self):
        ids = mk_ids()
        a = ids.create_identity("alice", "user")
        sig = ids.sign_as(a.did, {"amount": 10})
        self.assertFalse(ids.verify_for(a.did, sig, {"amount": 9999}))

    def test_I1_did_document_and_web_alias_wellknown(self):
        import tempfile
        from pathlib import Path
        root = Path(tempfile.mkdtemp())
        ids = IdentityService(default_backend(), FixedClock(), wellknown_root=root)
        a = ids.create_identity("open-agent", "agent")
        alias = ids.register_web_alias(a.did, "agents.example.com")
        self.assertEqual(alias, "did:web:agents.example.com")
        self.assertTrue((root / "agents.example.com" / ".well-known" / "did.json").exists())
        self.assertEqual(ids.get(alias).did, a.did)
        doc = ids.resolve_document(a.did)
        self.assertEqual(doc["id"], a.did)
        self.assertEqual(doc["verificationMethod"][0]["publicKeyHex"], a.public_key_hex)

    def test_I1_verifiable_credential_issue_verify_expiry(self):
        clock = FixedClock()
        ids = mk_ids(clock)
        issuer = ids.create_identity("org", "service")
        subject = ids.create_identity("agent", "agent")
        vc = ids.issue_vc(issuer.did, subject.did, {"role": "purchaser"}, ttl=60)
        ok, why = ids.verify_vc(vc)
        self.assertTrue(ok, why)
        clock.advance(61)
        ok, why = ids.verify_vc(vc)
        self.assertFalse(ok)
        self.assertEqual(why, "expired")

    def test_I4_session_token_expiry_audience_revocation(self):
        clock = FixedClock()
        ids = mk_ids(clock)
        a = ids.create_identity("agent", "agent")
        tok = ids.issue_token(a.did, "proto-os", ["agent"], ttl=100)
        self.assertEqual(ids.verify_token(tok, "proto-os"), (True, "ok"))
        self.assertEqual(ids.verify_token(tok, "other")[1], "wrong-audience")
        ids.revoke_token(tok)
        self.assertEqual(ids.verify_token(tok, "proto-os")[1], "revoked")
        tok2 = ids.issue_token(a.did, "proto-os", ["agent"], ttl=10)
        clock.advance(11)
        self.assertEqual(ids.verify_token(tok2, "proto-os")[1], "expired")

    def test_I4_rfc8693_token_exchange_act_chain(self):
        ids = mk_ids()
        user = ids.create_identity("user", "user")
        tok = ids.issue_token(user.did, "proto-os", ["read"])
        tok2 = ids.exchange_token(tok, "downstream-service")
        self.assertEqual(tok2["sub"], user.did)
        self.assertEqual(tok2["aud"], "downstream-service")
        self.assertEqual(tok2["act"], [user.did])
        self.assertEqual(ids.verify_token(tok2, "downstream-service"), (True, "ok"))

    def test_I2_oidc_tap_bridge(self):
        ids = mk_ids()
        idp = EnterpriseIdPStub("https://idp.corp", ids)
        idp.add_user("emp-42", "s3cret")
        with self.assertRaises(ProtoError):
            idp.authenticate("emp-42", "wrong")
        id_token = idp.authenticate("emp-42", "s3cret")
        agent = ids.create_identity("hr-agent", "agent")
        proto_tok = idp.bridge_to_proto(id_token, agent.did, ["hr.read"])
        self.assertEqual(ids.verify_token(proto_tok, "proto-os"), (True, "ok"))
        self.assertIn("https://idp.corp:emp-42", proto_tok["act"])


class TestAuditAndTracing(unittest.TestCase):
    def test_G3_audit_chain_verifies(self):
        log = AuditLog(FixedClock())
        for i in range(5):
            log.append("actor", "unit.test", {"i": i})
        ok, bad = log.verify()
        self.assertTrue(ok)
        self.assertIsNone(bad)
        self.assertEqual(len(log.by_action("unit.")), 5)

    def test_G3_audit_chain_detects_tamper(self):
        log = AuditLog(FixedClock())
        for i in range(5):
            log.append("actor", "unit.test", {"i": i})
        log.entries[2]["payload"]["i"] = 999  # tamper
        ok, bad = log.verify()
        self.assertFalse(ok)
        self.assertEqual(bad, 2)

    def test_O1_tracer_nested_spans_parenting(self):
        clock = FixedClock()
        tr = Tracer(clock)
        with tr.span("outer", {"k": 1}) as outer:
            clock.advance(0.5)
            with tr.span("inner") as inner:
                clock.advance(0.25)
        inner_s = next(s for s in tr.spans if s["name"] == "inner")
        outer_s = next(s for s in tr.spans if s["name"] == "outer")
        self.assertEqual(inner_s["parent_id"], outer["span_id"])
        self.assertEqual(inner_s["trace_id"], outer_s["trace_id"])
        self.assertAlmostEqual(inner_s["duration_ms"], 250.0, places=3)
        self.assertAlmostEqual(outer_s["duration_ms"], 750.0, places=3)

    def test_O1_tracer_marks_errors(self):
        tr = Tracer(FixedClock())
        with self.assertRaises(ValueError):
            with tr.span("boom"):
                raise ValueError("nope")
        self.assertEqual(tr.spans[0]["status"], "error")


class TestPolicyEngine(unittest.TestCase):
    def setUp(self):
        self.audit = AuditLog(FixedClock())
        self.engine = PolicyEngine(self.audit)

    def test_G1_safe_eval_ops(self):
        ctx = {"amount": 30, "category": "digital", "hour": 14, "tags": ["a", "b"]}
        self.assertTrue(safe_eval("amount <= 50 and category in ['digital','books']", ctx))
        self.assertTrue(safe_eval("10 < amount < 40", ctx))
        self.assertTrue(safe_eval("not (hour > 22) or 'a' in tags", ctx))
        self.assertFalse(safe_eval("amount > 100", ctx))

    def test_G1_safe_eval_blocks_dangerous(self):
        for expr in ["__import__('os')", "().__class__", "open('x')", "amount + 1 > 0"]:
            with self.assertRaises(ProtoError, msg=expr):
                safe_eval(expr, {"amount": 1})
        with self.assertRaises(ProtoError):
            safe_eval("unknown_var == 1", {})

    def test_G2_layer_precedence_deny_overrides(self):
        self.engine.add_rule("user", "allow", ["payment.settle"], "amount <= 1000")
        self.engine.add_rule("platform", "deny", ["payment.*"], "amount > 100",
                             description="platform cap")
        d = self.engine.evaluate("payment.settle", {"amount": 500})
        self.assertEqual(d.effect, "deny")
        d2 = self.engine.evaluate("payment.settle", {"amount": 50})
        self.assertEqual(d2.effect, "allow")

    def test_G2_require_approval_effect(self):
        self.engine.add_rule("user", "allow", ["payment.settle"])
        self.engine.add_rule("org", "require_approval", ["payment.settle"], "amount > 50")
        self.assertEqual(self.engine.evaluate("payment.settle", {"amount": 51}).effect,
                         "require_approval")
        self.assertEqual(self.engine.evaluate("payment.settle", {"amount": 49}).effect,
                         "allow")

    def test_G2_default_deny_sensitive_allow_benign(self):
        self.assertEqual(self.engine.evaluate("payment.settle", {"amount": 1}).effect, "deny")
        self.assertEqual(self.engine.evaluate("delegate", {}).effect, "deny")
        self.assertEqual(self.engine.evaluate("tool.call", {"tool": "echo"}).effect, "allow")

    def test_G3_policy_decisions_audited(self):
        self.engine.evaluate("tool.call", {"tool": "echo"}, actor="agent-1")
        entries = self.audit.by_action("policy.decision")
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["payload"]["action"], "tool.call")
        ok, _ = self.audit.verify()
        self.assertTrue(ok)


class TestMandates(unittest.TestCase):
    def setUp(self):
        self.clock = FixedClock()
        self.ids = mk_ids(self.clock)
        self.audit = AuditLog(self.clock)
        self.store = MandateStore(self.ids, self.audit, self.clock)
        self.user = self.ids.create_identity("user", "user")
        self.merchant = self.ids.create_identity("shop", "merchant")

    def _chain(self, total=20.0, pay_amount=None, max_amount=100.0,
               categories=("digital",), item_category="digital"):
        intent = self.store.issue_intent(self.user.did, "buy an ebook", max_amount, "USD",
                                         list(categories) if categories else None)
        cart = self.store.issue_cart(self.merchant.did, intent["id"],
                                     [{"sku": "bk1", "qty": 1, "category": item_category}],
                                     total, "USD")
        pay = self.store.issue_payment(self.user.did, cart["id"],
                                       pay_amount if pay_amount is not None else total,
                                       "USD", "x402", self.merchant.did)
        return intent, cart, pay

    def test_I3_mandate_chain_happy(self):
        _, _, pay = self._chain()
        ok, why = self.store.verify_chain(pay["id"])
        self.assertTrue(ok, why)
        self.assertTrue(any(e["action"] == "mandate.chain_verified"
                            for e in self.audit.entries))

    def test_I3_chain_rejects_amount_mismatch(self):
        _, _, pay = self._chain(total=20.0, pay_amount=25.0)
        ok, why = self.store.verify_chain(pay["id"])
        self.assertFalse(ok)
        self.assertEqual(why, "amount-mismatch")

    def test_I3_chain_rejects_intent_expired(self):
        _, _, pay = self._chain()
        self.clock.advance(4000)
        ok, why = self.store.verify_chain(pay["id"])
        self.assertFalse(ok)
        self.assertEqual(why, "intent-expired")

    def test_I3_chain_rejects_over_intent_max(self):
        _, _, pay = self._chain(total=150.0, max_amount=100.0)
        ok, why = self.store.verify_chain(pay["id"])
        self.assertFalse(ok)
        self.assertEqual(why, "exceeds-intent-max")

    def test_I3_chain_rejects_wrong_category(self):
        _, _, pay = self._chain(categories=("groceries",), item_category="digital")
        ok, why = self.store.verify_chain(pay["id"])
        self.assertFalse(ok)
        self.assertTrue(why.startswith("category-not-authorized"))

    def test_I3_chain_rejects_forged_signature(self):
        _, _, pay = self._chain()
        pay["sig"] = "00" * len(bytes.fromhex(pay["sig"]))
        ok, why = self.store.verify_chain(pay["id"])
        self.assertFalse(ok)
        self.assertEqual(why, "payment-signature-invalid")


if __name__ == "__main__":
    unittest.main()
