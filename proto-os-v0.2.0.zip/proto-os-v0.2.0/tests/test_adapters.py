import json
import unittest
import urllib.request

from protoos import (AGUIBus, A2AAdapter, AuditLog, FixedClock, IdentityService,
                     InputRequired, KillSwitch, MCPClient, MCPMux, MCPServer,
                     PolicyEngine, ProtoError, ProtoHalted, ProtoOS, RateLimited,
                     RateLimiter, ResourceCache, SandboxedExecutor, SessionManager,
                     TaskGraph, Tracer, default_backend, openapi_to_mcp)
from protoos.a2a import (COMPLETED, FAILED, INPUT_REQUIRED, CANCELED, RUN_STARTED,
                         STATE_DELTA, TEXT_MESSAGE)
from protoos.httpapi import start_http, stop_http
from protoos.wallet import X402Rail


class TestMCP(unittest.TestCase):
    def test_T1_mcp_initialize_list_call(self):
        srv = MCPServer("util")
        srv.add_tool("echo", "echo back", {"type": "object",
                                           "properties": {"text": {"type": "string"}},
                                           "required": ["text"]},
                     lambda text: {"echo": text})
        cli = MCPClient(srv.handle)
        info = cli.initialize()
        self.assertEqual(info["serverInfo"]["name"], "util")
        tools = cli.list_tools()
        self.assertEqual([t["name"] for t in tools], ["echo"])
        resp = cli.call("echo", {"text": "hi"})
        self.assertEqual(resp["result"]["structuredContent"], {"echo": "hi"})
        bad = cli.call("nope", {})
        self.assertIn("error", bad)
        missing = cli.call("echo", {})
        self.assertEqual(missing["error"]["code"], -32602)

    def test_T1_paid_tool_402_then_receipt(self):
        clock = FixedClock()
        ids = IdentityService(default_backend(), clock)
        audit = AuditLog(clock)
        rail = X402Rail(ids, audit, clock)
        payer = ids.create_identity("payer", "agent")
        payee = ids.create_identity("toolco", "merchant")
        srv = MCPServer("paid", x402_rail=rail, payee_did=payee.did)
        srv.add_tool("premium", "paid answer", {"type": "object", "properties": {}},
                     lambda: {"answer": 42}, price=0.10)
        cli = MCPClient(srv.handle)
        first = cli.call("premium", {})
        self.assertEqual(first["error"]["code"], 402)
        ch = first["error"]["data"]["challenge"]
        receipt = rail.settle(rail.build_payment(ch, payer.did)).to_json()
        second = cli.call("premium", {}, receipt=receipt)
        self.assertEqual(second["result"]["structuredContent"], {"answer": 42})
        # a receipt for the wrong resource is rejected
        other = rail.settle(rail.build_payment(
            rail.challenge("other", 0.10, "USD", payee.did), payer.did)).to_json()
        third = cli.call("premium", {}, receipt=other)
        self.assertEqual(third["error"]["code"], 402)

    def test_T2_mux_federation_namespacing(self):
        a, b = MCPServer("a"), MCPServer("b")
        a.add_tool("echo", "e", {"type": "object", "properties": {}}, lambda: "A")
        b.add_tool("echo", "e", {"type": "object", "properties": {}}, lambda: "B")
        mux = MCPMux()
        mux.mount("alpha", a)
        mux.mount("beta", b)
        cli = MCPClient(mux.handle)
        names = sorted(t["name"] for t in cli.list_tools())
        self.assertEqual(names, ["alpha.echo", "beta.echo"])
        self.assertEqual(cli.call("beta.echo", {})["result"]["structuredContent"],
                         {"value": "B"})
        self.assertIn("error", cli.call("gamma.echo", {}))
        self.assertIn("error", cli.call("noprefix", {}))

    def test_T2_openapi_to_mcp_offline(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "petstore"},
            "servers": [{"url": "https://api.example.com/v1"}],
            "paths": {
                "/pets/{petId}": {
                    "get": {"operationId": "getPet", "summary": "Fetch a pet",
                            "parameters": [{"name": "petId", "in": "path",
                                            "required": True,
                                            "schema": {"type": "string"}}]}},
                "/pets": {
                    "post": {"operationId": "createPet", "summary": "Create a pet",
                             "requestBody": {"content": {"application/json": {
                                 "schema": {"type": "object", "required": ["name"],
                                            "properties": {
                                                "name": {"type": "string"},
                                                "age": {"type": "integer"}}}}}}}},
            },
        }
        srv = openapi_to_mcp(spec)
        cli = MCPClient(srv.handle)
        tools = {t["name"]: t for t in cli.list_tools()}
        self.assertEqual(set(tools), {"getPet", "createPet"})
        self.assertEqual(tools["getPet"]["inputSchema"]["required"], ["petId"])
        self.assertIn("age", tools["createPet"]["inputSchema"]["properties"])
        self.assertTrue(tools["getPet"]["annotations"]["readOnlyHint"])
        out = cli.call("getPet", {"petId": "p1"})["result"]["structuredContent"]
        self.assertTrue(out["simulated"])
        self.assertEqual(out["url"], "https://api.example.com/v1/pets/{petId}")
        self.assertEqual(out["args"], {"petId": "p1"})

    def test_T3_resource_cache_policy_and_lru(self):
        audit = AuditLog(FixedClock())
        engine = PolicyEngine(audit)
        engine.add_rule("org", "deny", ["cache.read"],
                        "scope == 'secret' and 'secret' not in requester_scopes")
        cache = ResourceCache(engine, audit, maxsize=2)
        cache.put("prompt:sys", "You are helpful", scope="public")
        cache.put("kb:internal", "launch codes", scope="secret")
        self.assertEqual(cache.get("prompt:sys", "agent1", []), "You are helpful")
        self.assertIsNone(cache.get("kb:internal", "agent1", []))
        self.assertEqual(cache.get("kb:internal", "agent2", ["secret"]), "launch codes")
        cache.put("third", 3, scope="public")  # evicts LRU
        self.assertEqual(len(cache._data), 2)


class TestA2A(unittest.TestCase):
    def setUp(self):
        self.clock = FixedClock()
        self.audit = AuditLog(self.clock)
        self.a2a = A2AAdapter(self.clock, self.audit)

    def test_R1_task_lifecycle_completed(self):
        self.a2a.register_handler("did:proto:w", lambda t, m, c: f"done: {m}")
        t = self.a2a.message_send("did:proto:w", "hello")
        self.assertEqual(t.state, COMPLETED)
        self.assertEqual(t.artifacts[0]["parts"][0]["text"], "done: hello")
        got = self.a2a.tasks_get(t.id)
        self.assertEqual(got.to_json()["status"]["state"], COMPLETED)

    def test_R1_input_required_resume_long_running(self):
        def handler(task, msg, ctx):
            if "confirm" not in msg:
                raise InputRequired("please confirm")
            return "confirmed"
        self.a2a.register_handler("did:proto:w", handler)
        t = self.a2a.message_send("did:proto:w", "start")
        self.assertEqual(t.state, INPUT_REQUIRED)
        t2 = self.a2a.provide_input(t.id, "confirm yes")
        self.assertEqual(t2.state, COMPLETED)
        with self.assertRaises(ProtoError):
            self.a2a.provide_input(t.id, "again")

    def test_R1_failed_and_canceled(self):
        self.a2a.register_handler("did:proto:bad", lambda t, m, c: 1 / 0)
        t = self.a2a.message_send("did:proto:bad", "x")
        self.assertEqual(t.state, FAILED)

        def waits(task, msg, ctx):
            raise InputRequired("hold")
        self.a2a.register_handler("did:proto:w", waits)
        t2 = self.a2a.message_send("did:proto:w", "x")
        t2 = self.a2a.cancel(t2.id)
        self.assertEqual(t2.state, CANCELED)

    def test_R1_jsonrpc_surface(self):
        self.a2a.register_handler("did:proto:w", lambda t, m, c: "ok")
        resp = self.a2a.handle({"jsonrpc": "2.0", "id": 1, "method": "message/send",
                                "params": {"to": "did:proto:w", "message": "hi"}})
        task_id = resp["result"]["id"]
        got = self.a2a.handle({"jsonrpc": "2.0", "id": 2, "method": "tasks/get",
                               "params": {"id": task_id}})
        self.assertEqual(got["result"]["status"]["state"], COMPLETED)
        err = self.a2a.handle({"jsonrpc": "2.0", "id": 3, "method": "tasks/get",
                               "params": {"id": "task_missing"}})
        self.assertIn("error", err)


class TestAGUI(unittest.TestCase):
    def test_U1_event_stream_order_and_multiclient(self):
        bus = AGUIBus(FixedClock())
        seen_a, seen_b = [], []
        bus.subscribe("run1", seen_a.append)
        bus.subscribe("run1", seen_b.append)
        bus.emit("run1", RUN_STARTED, {"agent": "x"})
        bus.emit("run1", TEXT_MESSAGE, {"text": "hi"})
        self.assertEqual([e["type"] for e in bus.events("run1")],
                         [RUN_STARTED, TEXT_MESSAGE])
        self.assertEqual(len(seen_a), 2)
        self.assertEqual(len(seen_b), 2)
        self.assertEqual(bus.events("other"), [])

    def test_U2_state_delta_shared_state(self):
        bus = AGUIBus(FixedClock())
        st = bus.apply_state_delta("run1", {"step": 1})
        st = bus.apply_state_delta("run1", {"step": 2, "cart": 3})
        self.assertEqual(st, {"step": 2, "cart": 3})
        deltas = [e for e in bus.events("run1") if e["type"] == STATE_DELTA]
        self.assertEqual(len(deltas), 2)
        self.assertEqual(deltas[1]["data"]["state"], {"step": 2, "cart": 3})


class TestHTTPTransport(unittest.TestCase):
    def test_X4_http_jsonrpc_wellknown_and_sse(self):
        os_ = ProtoOS(FixedClock())
        srv = os_.make_mcp_server("util")
        srv.add_tool("echo", "echo", {"type": "object",
                                      "properties": {"t": {"type": "string"}}},
                     lambda t="": {"echo": t})
        os_.mount_mcp("util", srv)
        os_.create_agent("greeter", "says hello",
                         handler=lambda task, msg, ctx: f"hello {msg}")
        agent_did = next(iter(os_._agents))
        server, thread, port = start_http(os_)
        try:
            def post(path, payload):
                req = urllib.request.Request(
                    f"http://127.0.0.1:{port}{path}",
                    data=json.dumps(payload).encode(),
                    headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=5) as r:
                    return json.loads(r.read())

            tools = post("/mcp", {"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
            self.assertIn("util.echo", [t["name"] for t in tools["result"]["tools"]])
            call = post("/mcp", {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                                 "params": {"name": "util.echo",
                                            "arguments": {"t": "ping"}}})
            self.assertEqual(call["result"]["structuredContent"], {"echo": "ping"})
            sent = post("/a2a", {"jsonrpc": "2.0", "id": 3, "method": "message/send",
                                 "params": {"to": agent_did, "message": "world"}})
            self.assertEqual(sent["result"]["status"]["state"], COMPLETED)
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/healthz",
                                        timeout=5) as r:
                self.assertTrue(json.loads(r.read())["ok"])
            with urllib.request.urlopen(
                    f"http://127.0.0.1:{port}/.well-known/agents", timeout=5) as r:
                agents = json.loads(r.read())["agents"]
            self.assertIn("greeter", [a["name"] for a in agents])
            rid, _ = os_.run(agent_did, "again")
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/agui/{rid}",
                                        timeout=5) as r:
                body = r.read().decode()
                self.assertEqual(r.headers.get("Content-Type"), "text/event-stream")
            self.assertIn(RUN_STARTED, body)
            self.assertIn("data: [DONE]", body)
        finally:
            stop_http(server, thread)


class TestRuntimePrimitives(unittest.TestCase):
    def test_G4_rate_limiter_token_bucket(self):
        clock = FixedClock()
        rl = RateLimiter(clock, rate_per_sec=1.0, burst=2)
        self.assertTrue(rl.allow("k"))
        self.assertTrue(rl.allow("k"))
        with self.assertRaises(RateLimited):
            rl.check("k")
        clock.advance(1.0)
        self.assertTrue(rl.allow("k"))

    def test_G4_killswitch_scoped_and_global(self):
        ks = KillSwitch()
        ks.check("did:proto:a")
        ks.engage("did:proto:a")
        with self.assertRaises(ProtoHalted):
            ks.check("did:proto:a")
        ks.check("did:proto:b")
        ks.engage()  # global
        with self.assertRaises(ProtoHalted):
            ks.check("did:proto:b")
        ks.release()
        ks.release("did:proto:a")
        ks.check("did:proto:a")

    def test_G4_sandbox_whitelist_and_size(self):
        sb = SandboxedExecutor(max_arg_bytes=32)
        sb.grant("add", lambda a, b: a + b)
        self.assertEqual(sb.run("add", a=2, b=3), 5)
        with self.assertRaises(ProtoError):
            sb.run("os_system", cmd="rm -rf /")
        with self.assertRaises(ProtoError):
            sb.run("add", a="x" * 100, b="y")

    def test_R3_taskgraph_dag_order_and_cycle(self):
        tr = Tracer(FixedClock())
        g = TaskGraph("pipeline")
        g.add("fetch", lambda: 10)
        g.add("double", lambda fetch: fetch * 2, deps=["fetch"])
        g.add("report", lambda double: f"value={double}", deps=["double"])
        out = g.run(tracer=tr)
        self.assertEqual(out["report"], "value=20")
        self.assertEqual(len([s for s in tr.spans if s["name"].startswith("graph:")]), 3)
        bad = TaskGraph("cyc").add("a", lambda b: b, deps=["b"]).add(
            "b", lambda a: a, deps=["a"])
        with self.assertRaises(ProtoError):
            bad.run()
        ks = KillSwitch()
        ks.engage()
        with self.assertRaises(ProtoHalted):
            TaskGraph("halted").add("x", lambda: 1).run(killswitch=ks)

    def test_R4_session_manager_long_running(self):
        sm = SessionManager(FixedClock())
        sid = sm.create("did:proto:a", {"turn": 0})
        sm.update(sid, turn=1)
        st = sm.update(sid, notes="remember this")
        self.assertEqual(st, {"turn": 1, "notes": "remember this"})
        sm.close(sid)
        with self.assertRaises(ProtoError):
            sm.update(sid, turn=2)


if __name__ == "__main__":
    unittest.main()
